/* ==========================================================================
   TRAILBLAZER SECOND EDITION — game data
   Transcribed from the rulebook. All mechanical values are sourced from the
   text; a handful of item "bulk" values that weren't explicitly listed for
   a given weapon were estimated by analogy to similar listed items (flagged
   with est:true below).
   ========================================================================== */

const ATTRIBUTES = ["Agility", "Body", "Mind", "Spirit", "Luck"];

const ATTR_BLURB = {
  Agility: "Accuracy and speed",
  Body: "Health and strength",
  Mind: "Wisdom and intelligence",
  Spirit: "Resolve and faith",
  Luck: "Chance and providence",
};

// score -> modifier, per the book's table (score - 6)
function scoreToMod(score) {
  return score - 6;
}
function fmtMod(n) {
  return n >= 0 ? `+${n}` : `${n}`;
}

const SKILLS = [
  { name: "Acrobatics", attr: "Agility", use: "Measures flexibility" },
  { name: "Athletics", attr: "Body", use: "Measures strength" },
  { name: "Deception", attr: "Spirit", use: "Hides the truth" },
  { name: "Endurance", attr: "Body", use: "Measures physical tolerance" },
  { name: "Etymology", attr: "Mind", use: "Uses or understands language" },
  { name: "Fortitude", attr: "Mind", use: "Measures mental tolerance" },
  { name: "Fortuity", attr: "Luck", use: "Measures luck" },
  { name: "History", attr: "Mind", use: "Measures historical knowledge" },
  { name: "Investigation", attr: "Mind", use: "Looks into something closely" },
  { name: "Intimidation", attr: "Spirit", use: "Strikes fear or anger into someone" },
  { name: "Medication", attr: "Mind", use: "Uses or understands medicine" },
  { name: "Perception", attr: "Mind", use: "Scans surroundings or motives" },
  { name: "Performance", attr: "Spirit", use: "Entertains or puts on a show" },
  { name: "Persuasion", attr: "Spirit", use: "Convinces someone" },
  { name: "Reflex", attr: "Agility", use: "Measures reaction time" },
  { name: "Religion", attr: "Mind", use: "Measures religious knowledge" },
  { name: "Stealth", attr: "Agility", use: "Moves cautiously with little noise" },
  { name: "Technique", attr: "Agility", use: "Measures finesse" },
  { name: "Technology", attr: "Mind", use: "Measures technological knowledge" },
  { name: "Willpower", attr: "Spirit", use: "Avoids temptations" },
];

const ADEPT_DICE = [
  { lvl: [1, 2], dice: "1d4" },
  { lvl: [3, 4], dice: "1d6" },
  { lvl: [5, 6], dice: "1d8" },
  { lvl: [7, 8], dice: "2d4" },
  { lvl: [9, 10], dice: "2d6" },
  { lvl: [11, 12], dice: "3d4" },
];
const INEPT_DICE = [
  { lvl: [1, 2], dice: "3d4" },
  { lvl: [3, 4], dice: "2d6" },
  { lvl: [5, 6], dice: "2d4" },
  { lvl: [7, 8], dice: "1d8" },
  { lvl: [9, 10], dice: "1d6" },
  { lvl: [11, 12], dice: "1d4" },
];
function diceForLevel(table, level) {
  const row = table.find((r) => level >= r.lvl[0] && level <= r.lvl[1]);
  return row ? row.dice : table[table.length - 1].dice;
}

const XP_TABLE = [
  { level: 1, xp: 0 }, { level: 2, xp: 25 }, { level: 3, xp: 75 },
  { level: 4, xp: 125 }, { level: 5, xp: 200 }, { level: 6, xp: 325 },
  { level: 7, xp: 525 }, { level: 8, xp: 850 }, { level: 9, xp: 1375 },
  { level: 10, xp: 1900 }, { level: 11, xp: 2205 }, { level: 12, xp: 2725 },
];

const DR_TABLE = [
  { challenge: "Very easy", range: "1–8" },
  { challenge: "Easy", range: "9–16" },
  { challenge: "Normal", range: "17–24" },
  { challenge: "Hard", range: "25–32" },
  { challenge: "Very Hard", range: "33–40" },
];

/* Casting an "exhaustive" power gives 1 Exhaustion point. A long rest clears 2
   points, a short rest clears 1. Effects are cumulative up to the current total. */
const EXHAUSTION_TABLE = [
  { points: 1, effect: "\u22125ft of movement" },
  { points: 2, effect: "\u22122 penalty on skill checks" },
  { points: 3, effect: "\u22122 penalty on saving rolls" },
  { points: 4, effect: "\u22122 penalty on damage rolls" },
  { points: 5, effect: "\u22122 penalty on attack rolls" },
  { points: 6, effect: "Every d20 roll is made twice, using the lower result" },
  { points: 7, effect: "\u221210ft of movement" },
  { points: 8, effect: "Any healing received is half as effective" },
  { points: 9, effect: "Every d20 roll automatically fails" },
  { points: 10, effect: "\u221215ft of movement" },
  { points: 11, effect: "Every d20 roll is automatically a critical failure" },
  { points: 12, effect: "Death" },
];

const DAMAGE_TYPES = {
  Physical: ["slashing", "bludgeoning", "piercing"],
  Energy: ["plasma", "ion", "sonic"],
  Elemental: ["fire", "force", "frost"],
  Sacred: ["radiant", "necrotic", "unknown"],
  Misc: ["psychic", "acid", "poison"],
};

const ACTION_ICONS = { ">>": "2 actions", ">": "1 action", "<": "1 reaction", "": "No cost" };

/* --------------------------------- SPECIES -------------------------------- */
const SPECIES = [
  {
    name: "Centaurian",
    blurb: "Star-spirits from the Centaur Sun given form by the Vessel called the Suncircle.",
    mods: { Body: 2, Mind: 1 },
    languages: ["Standard Galactic", "Centauri"],
    resist: ["radiant", "fire"],
    vuln: ["frost", "necrotic"],
    innate: { name: "Vessel Taught", text: "Auto-succeed on one History or Etymology check per long rest." },
    hpBonus: 12,
  },
  {
    name: "Eidean",
    blurb: "Natives of the Grand Galaxy; defensive, cautious, and orderly city-planet dwellers.",
    mods: { Spirit: 2, Agility: 1 },
    languages: ["Standard Galactic", "Eidari"],
    resist: ["ion", "force"],
    vuln: ["plasma", "fire"],
    innate: { name: "Keen", text: "Auto-succeed on one Physical saving roll per long rest." },
    hpBonus: 10,
  },
  {
    name: "Gelpgha",
    blurb: "Fishlike, amphibious researchers from the watery world of Anara.",
    mods: { Mind: 2, Agility: 1 },
    languages: ["Common", "Graw"],
    resist: ["psychic", "poison"],
    vuln: ["acid", "ion"],
    innate: { name: "Clever", text: "Auto-succeed on one Mental saving roll per long rest." },
    hpBonus: 8,
  },
  {
    name: "Human",
    blurb: "Refugees of Earth, mostly settled on Cansas; accurate duelists still proving themselves.",
    mods: { Agility: 2, Body: 1 },
    languages: ["Standard Galactic", "Earthlike"],
    resist: ["ion", "poison"],
    vuln: ["plasma", "frost"],
    innate: { name: "Adapted", text: "Reroll your Adept dice twice per long rest." },
    hpBonus: 10,
  },
  {
    name: "Kilkiri",
    blurb: "Birdlike apex-predator hunters, rescued from a nearly-extinct homeworld.",
    mods: { Body: 2, Agility: 1 },
    languages: ["Standard Galactic", "Makari"],
    resist: ["bludgeoning", "frost"],
    vuln: ["fire", "poison"],
    innate: { name: "Hunter", text: "Auto-succeed on one Perception or Investigation check per long rest." },
    hpBonus: 12,
  },
  {
    name: "Lauketh",
    blurb: "Lizardlike warriors of Raught, reborn from the great tree Nubrik after death.",
    mods: { Agility: 2, Body: 1 },
    languages: ["Standard Galactic", "Rau"],
    resist: ["slashing", "necrotic"],
    vuln: ["bludgeoning", "psychic"],
    innate: { name: "Keen", text: "Auto-succeed on one Physical saving roll per long rest." },
    hpBonus: 12,
  },
  {
    name: "Tyleen",
    blurb: "Deceptive, lucky tendril-headed beings from the neon metropolis of Neet.",
    mods: { Luck: 2, Spirit: 1 },
    languages: ["Standard Galactic", "Neetish"],
    resist: ["piercing", "acid"],
    vuln: ["radiant", "sonic"],
    innate: { name: "Charm", text: "Auto-succeed on one Fortuity or Deception check per long rest." },
    hpBonus: 10,
  },
  {
    name: "Voisard",
    blurb: "Opportunistic ritualists of Exile, well versed in the galaxy's religions.",
    mods: { Spirit: 2, Body: 1 },
    languages: ["Standard Galactic", "Izard"],
    resist: ["psychic", "plasma"],
    vuln: ["necrotic", "poison"],
    innate: { name: "Savior", text: "Auto-succeed on one Spiritual saving roll per long rest." },
    hpBonus: 10,
  },
];

/* --------------------------------- ORIGINS -------------------------------- */
const ORIGINS = [
  // Centaur System — the Living Star
  { name: "Ace 2", system: "Centaur", adept: ["Performance", "Fortuity"], inept: ["Stealth", "Perception"] },
  { name: "Cansas", system: "Centaur", adept: ["Technology", "Technique"], inept: ["Medication", "Persuasion"] },
  { name: "Little Rock", system: "Centaur", adept: ["Technology", "Persuasion"], inept: ["Etymology", "Willpower"] },
  { name: "Minneapolis", system: "Centaur", adept: ["Perception", "Investigation"], inept: ["Deception", "Reflex"] },
  { name: "Tannis", system: "Centaur", adept: ["Stealth", "Reflex"], inept: ["Fortitude", "Acrobatics"] },
  { name: "Venesa", system: "Centaur", adept: ["Athletics", "Technique"], inept: ["Fortuity", "Deception"] },
  { name: "Weston", system: "Centaur", adept: ["Intimidation", "Endurance"], inept: ["History", "Technology"] },
  // Daark System — the Lightless Star
  { name: "Dather", system: "Daark", adept: ["Endurance", "Fortitude"], inept: ["Investigation", "Persuasion"] },
  { name: "Erbel", system: "Daark", adept: ["Medication", "Willpower"], inept: ["Perception", "Intimidation"] },
  { name: "Exile", system: "Daark", adept: ["Religion", "Willpower"], inept: ["History", "Reflex"] },
  { name: "Faug", system: "Daark", adept: ["Perception", "Reflex"], inept: ["Willpower", "Acrobatics"] },
  { name: "Hadar", system: "Daark", adept: ["Acrobatics", "Reflex"], inept: ["Fortuity", "Fortitude"] },
  { name: "Moradeane", system: "Daark", adept: ["Willpower", "Etymology"], inept: ["Performance", "History"] },
  { name: "Raught", system: "Daark", adept: ["Endurance", "Reflex"], inept: ["Fortitude", "Technology"] },
  { name: "Neet", system: "Daark", adept: ["Fortuity", "Deception"], inept: ["Fortitude", "Technique"] },
  // Hyll System — the Loving Star
  { name: "Anara", system: "Hyll", adept: ["Medication", "Persuasion"], inept: ["Deception", "Athletics"] },
  { name: "Bume", system: "Hyll", adept: ["Stealth", "Willpower"], inept: ["Investigation", "Acrobatics"] },
  { name: "Deshkar", system: "Hyll", adept: ["Intimidation", "Technique"], inept: ["Fortitude", "History"] },
  { name: "Edison", system: "Hyll", adept: ["Perception", "Etymology"], inept: ["Deception", "Intimidation"] },
  { name: "Eideaos", system: "Hyll", adept: ["Persuasion", "History"], inept: ["Religion", "Performance"] },
  { name: "Luwa", system: "Hyll", adept: ["Religion", "Technique"], inept: ["Fortuity", "Medication"] },
  { name: "Nidalus", system: "Hyll", adept: ["Performance", "Persuasion"], inept: ["Intimidation", "Technique"] },
  { name: "Yerradyne", system: "Hyll", adept: ["Intimidation", "Fortitude"], inept: ["Etymology", "Religion"] },
  { name: "Zunul", system: "Hyll", adept: ["Perception", "Technique"], inept: ["Technology", "Persuasion"] },
];

/* ---------------------------------- ROLES --------------------------------- */
const ROLES = [
  { name: "Analyst", adept: ["Medication", "Technology"], inept: ["Persuasion", "Intimidation"] },
  { name: "Artist", adept: ["Technique", "Performance"], inept: ["History", "Religion"] },
  { name: "Charlatan", adept: ["Deception", "Performance"], inept: ["Persuasion", "Willpower"] },
  { name: "Cultist", adept: ["Religion", "Perception"], inept: ["Persuasion", "Fortitude"] },
  { name: "Detective", adept: ["Persuasion", "Investigation"], inept: ["Athletics", "Endurance"] },
  { name: "Enforcer", adept: ["Athletics", "Intimidation"], inept: ["Technology", "Medication"] },
  { name: "Explorer", adept: ["Perception", "Endurance"], inept: ["Investigation", "History"] },
  { name: "Fugitive", adept: ["Acrobatics", "Stealth"], inept: ["Persuasion", "Willpower"] },
  { name: "Gunslinger", adept: ["Reflex", "Technique"], inept: ["Fortuity", "Fortitude"] },
  { name: "Soldier", adept: ["Athletics", "Endurance"], inept: ["Intimidation", "Persuasion"] },
  { name: "Speaker", adept: ["Persuasion", "Deception"], inept: ["Endurance", "Technique"] },
];

/* ---------------------------------- PATHS --------------------------------- */
/* slotTable: null if the path has no power-slot progression.
   Each row is [1st-level slots, 2nd-level slots, 3rd-level slots] for that character level (index 0 = level 1). */
const SLOT_TABLE_A = [ // Hotshot, Riskrunner
  [2,0,0],[2,0,0],[2,0,0],[2,1,0],[3,1,0],[3,2,0],[3,2,1],[3,2,1],[4,2,1],[4,3,2],[4,3,2],[4,3,2],
];
const SLOT_TABLE_B = [ // Bloodblade, Otherworlder, Songbird, Mentalist, Spiritualist
  [2,0,0],[2,0,0],[2,0,0],[3,1,0],[3,1,0],[3,2,0],[4,2,1],[4,2,1],[4,3,2],[5,3,2],[5,4,3],[5,4,3],
];

const PATHS = [
  {
    name: "Bioweapon",
    blurb: "A bio-engineered living weapon that thrives on rage and the frontline.",
    save: "Physical",
    weapons: ["Blades", "Blasters"],
    hitDie: "d12", hitDieAttr: "Body",
    resource: "mutation",
    slotTable: null,
    progression: [
      { lvl: 1, features: [{ name: "Rageful", action: ">>", text: "Become enraged: make attack rolls twice and use the higher result. Lasts until you spend an action to calm down. While enraged, you're Inept with Mental saving rolls and auto-fail Mind-related skill checks." }] },
      { lvl: 2, grants: { mp: 1, attrRaise: true } },
      { lvl: 3, features: [{ name: "Rageful", text: "While enraged, gain a resistance score of 2 against all damage types." }] },
      { lvl: 4, grants: { mp: 1, ap: 1 } },
      { lvl: 5, features: [
        { name: "Rageful", action: ">", text: "Becoming enraged only costs one action." },
        { name: "Regeneration", action: "<", text: "As a reaction to taking damage while enraged, roll your hit dice + half your Body modifier and regain that much health." },
      ] },
      { lvl: 6, grants: { mp: 2, adeptSaveChoice: ["Mental", "Spiritual"] } },
      { lvl: 7, features: [
        { name: "Rageful", text: "While enraged, resistance score against all damage becomes 4." },
        { name: "Regeneration", text: "Add your whole Body modifier to the healing roll instead of only half." },
      ] },
      { lvl: 8, grants: { mp: 2, ap: 1 } },
      { lvl: 9, features: [
        { name: "Rageful", text: "While enraged, you have three actions instead of two." },
        { name: "Regeneration", text: "Roll the healing dice twice and use the higher result." },
        { name: "Revenge", action: "<", text: "As a reaction to taking damage while enraged, make a weapon attack roll against the creature that damaged you." },
      ], grants: { mp: 3, adeptSkillChoice: true } },
      { lvl: 10, features: [{ name: "Rageful", text: "While enraged, make attack rolls three times and use the highest result." }] },
      { lvl: 11, grants: { mp: 3, adeptSkillChoice: true } },
      { lvl: 12, features: [{ name: "Rageful", text: "While enraged, resistance score against all damage becomes 6." }] },
    ],
  },
  {
    name: "Bloodblade",
    blurb: "A husk left behind by a failed Vessel bonding, who fuels attacks with their own blood.",
    save: "Physical",
    weapons: ["Blades", "Polearms"],
    hitDie: "d10", hitDieAttr: "Body",
    resource: "powerpoints",
    slotTable: SLOT_TABLE_B,
    progression: [
      { lvl: 1, features: [{ name: "Sanguine Strike", text: "Expend a 1st level power slot to add your hit dice (no Body modifier) to your next attack roll made with a Blade or Polearm." }] },
      { lvl: 2, grants: { pp: 2, weaponAdd: "Bows" } },
      { lvl: 3, features: [{ name: "Sanguine Strike", text: "On a successful attack roll with this ability, add your hit dice to the damage roll." }] },
      { lvl: 4, grants: { pp: 4, ap: 1 } },
      { lvl: 5, features: [
        { name: "Sanguine Strike", text: "On a critical success, the target begins to bleed (loses 2 HP after each action they take, for up to an hour, until healed)." },
        { name: "Sanguine Shot", text: "Expend a 2nd level power slot to add your hit dice to your next attack roll made with a Bow. Add half your Body modifier to this roll." },
      ] },
      { lvl: 6, grants: { pp: 6, adeptSaveChoice: ["Mental", "Spiritual"] } },
      { lvl: 7, features: [{ name: "Sanguine Shot", text: "On a successful attack roll with this ability, add your hit dice to the damage roll." }] },
      { lvl: 8, grants: { pp: 8, adeptSkillChoice: true } },
      { lvl: 9, features: [{ name: "Bloodbound", text: "Expend a 3rd level power slot to add your hit dice to your next saving roll." }] },
      { lvl: 10, grants: { attrRaise: true } },
      { lvl: 11, features: [{ name: "Bloodbound", text: "After succeeding on a save with this ability, all hostile creatures within 10ft must make a Physical saving roll against you or take 6d6 + Body modifier slashing damage." }] },
      { lvl: 12, grants: { ap: 1 } },
    ],
  },
  {
    name: "Hotshot",
    blurb: "A duelist obsessed with ranged weapons, altering the effects of their shots.",
    save: "Physical",
    weapons: ["Blasters", "Bows"],
    hitDie: "d10", hitDieAttr: "Body",
    resource: "slots",
    slotTable: SLOT_TABLE_A,
    progression: [
      { lvl: 1, features: [{ name: "Powered Shot", text: "Expend a 1st level power slot to add 1d4 to your next damage roll made with a Blaster or Bow." }] },
      { lvl: 2, grants: { ap: 1 } },
      { lvl: 3, features: [{ name: "Powered Shot", text: "Expend two 1st level power slots to add 2d4 to your next damage roll." }] },
      { lvl: 4, grants: { adeptSkillChoice: true } },
      { lvl: 5, features: [
        { name: "Powered Shot", text: "Expend three 1st level power slots to add 3d4 to your next damage roll." },
        { name: "Split Shot", text: "Expend a 2nd level power slot to target an additional creature/construct with a Blaster attack roll." },
      ] },
      { lvl: 6, grants: { ap: 1 } },
      { lvl: 7, features: [{ name: "Split Shot", text: "Expend two 2nd level power slots to target a third creature/construct." }] },
      { lvl: 8, grants: { adeptSaveChoice: ["Mental", "Spiritual"] } },
      { lvl: 9, features: [
        { name: "Powered Shot", text: "Expend four 1st level power slots to add 4d4 to your next damage roll." },
        { name: "Quick Shot", text: "Expend a 3rd level power slot to attack a target without using an action (your turn only)." },
      ] },
      { lvl: 10, grants: { attrRaise: true } },
      { lvl: 11, features: [
        { name: "Split Shot", text: "Expend three 2nd level power slots to target a fourth creature/construct." },
        { name: "Quick Shot", text: "Can now be used outside of your turn." },
      ] },
      { lvl: 12, grants: { adeptSkillChoice: true } },
    ],
  },
  {
    name: "Maverick",
    blurb: "A lone operator who works best without backup, striking from a distance.",
    save: "Physical",
    weapons: ["Blades", "Bows"],
    hitDie: "d10", hitDieAttr: "Body",
    resource: "none",
    slotTable: null,
    progression: [
      { lvl: 1, features: [
        { name: "Independence", text: "When making a skill check that only benefits you, roll twice and use the higher result." },
        { name: "Field Expertise", text: "While wearing Field armor, your AR is increased by half your Agility modifier." },
      ] },
      { lvl: 2, grants: { attrRaise: true } },
      { lvl: 3, features: [{ name: "Independence", text: "If you stand to gain more from a skill check than anyone else, roll twice and use the higher result." }] },
      { lvl: 4, grants: { ap: 1 } },
      { lvl: 5, features: [
        { name: "Independence", text: "When you're the only one making a saving roll, roll twice and use the higher result." },
        { name: "Isolation", text: "When attacking a target at least 25ft from their closest ally, roll twice and use the higher result." },
      ] },
      { lvl: 6, grants: { adeptSkillChoice: true } },
      { lvl: 7, features: [
        { name: "Independence", text: "When you and only one other target make the same saving roll, roll twice and use the higher result." },
        { name: "Isolation", text: "Threshold lowers to 20ft from the closest ally." },
      ] },
      { lvl: 8, grants: { adeptSaveChoice: ["Mental", "Spiritual"] } },
      { lvl: 9, features: [
        { name: "Independence", text: "Qualifying skill checks are rolled three times, highest result used." },
        { name: "Isolation", text: "Qualifying attack rolls are rolled three times, highest result used." },
        { name: "Instinctual", text: "When making an initiative roll, roll twice and use the higher result." },
      ] },
      { lvl: 10, grants: { ap: 1 } },
      { lvl: 11, features: [
        { name: "Independence", text: "Qualifying saving rolls are rolled three times, highest result used." },
        { name: "Instinctual", text: "Initiative rolls are rolled three times, highest result used." },
      ] },
      { lvl: 12, grants: { adeptSkillChoice: true } },
    ],
  },
  {
    name: "Mentalist",
    blurb: "You are able to focus your psychic powers.",
    save: "Mental",
    weapons: ["Blasters", "Blades"],
    hitDie: "d8", hitDieAttr: "Mind",
    resource: "powerpoints",
    slotTable: SLOT_TABLE_B,
    progression: [
      { lvl: 1, grants: { pp: "halfMind" }, features: [{ name: "Mental Powershape: Accuracy", text: "When you cast a clairvoyance or ordination power that requires an attack roll, expend an additional power slot of the same level to increase its accuracy — the attack roll becomes an automatic success." }] },
      { lvl: 2, grants: { ap: 1 } },
      { lvl: 3, features: [{ name: "Mental Powershape: Damage", text: "When you cast a clairvoyance or ordination power that deals damage, expend an additional power slot of the same level to increase its potency — add your Adept dice to the subsequent damage roll." }] },
      { lvl: 4, grants: { pp: 4, adeptSaveChoice: ["Physical", "Spiritual"] } },
      { lvl: 5, features: [{ name: "Mental Powershape: Duration", text: "When you cast a clairvoyance or ordination power that has a duration, expend an additional power slot of the same level to give it the concentration trait. When a power has the concentration trait, you can use an action to refresh its duration." }] },
      { lvl: 6, grants: { pp: 6, ap: 1 } },
      { lvl: 7, features: [{ name: "Mental Powershape: Save", text: "When a hostile creature makes a Mental saving roll against you, expend a 2nd level power slot to subtract your Adept dice from their roll." }] },
      { lvl: 8, grants: { pp: 8, attrRaise: true } },
      { lvl: 9, features: [{ name: "Mental Powershape: Save", text: "This now applies when a hostile creature makes a Physical, Mental, or Spiritual saving roll against you." }] },
      { lvl: 10, grants: { adeptSkillChoice: true } },
      { lvl: 11, features: [{ name: "Mental Powershape: Presence", text: "When a friendly creature makes a skill check, expend a 3rd level power slot to add your Adept dice to their roll." }] },
      { lvl: 12, grants: { pp: "halfMind" } },
    ],
  },
  {
    name: "Otherworlder",
    blurb: "An unkown representative of the universe has blessed your mind with cosmic powers.",
    save: "Mental",
    weapons: ["Blades", "Polearms"],
    hitDie: "d8", hitDieAttr: "Mind",
    resource: "powerpoints",
    slotTable: SLOT_TABLE_B,
    progression: [
      { lvl: 1, features: [{ name: "Disrupt", action: "<", text: "Signature 1st level clairvoyance power. As a reaction to a creature within 25ft casting a 1st level power, force a Spiritual save against you — on a fail, their power doesn't go through." }] },
      { lvl: 2, grants: { pp: 2, adeptSkillChoice: true } },
      { lvl: 3, features: [{ name: "Disrupt", text: "The Spiritual save can instead go against your Mental SL." }] },
      { lvl: 4, grants: { pp: 4, adeptSaveChoice: ["Physical", "Spiritual"] } },
      { lvl: 5, features: [
        { name: "Disrupt", text: "Cast with a 2nd level slot to also prevent a 2nd level power." },
        { name: "Suppress", action: ">", text: "Signature 2nd level clairvoyance power. Target within 30ft makes a Mental save or forgets how to use clairvoyance, ordination, sorcery, or technomancy powers for 1 minute." },
      ] },
      { lvl: 6, grants: { pp: 6, attrRaise: true } },
      { lvl: 7, features: [{ name: "Disrupt", text: "Cast with a 3rd level slot to also prevent a 3rd level power." }] },
      { lvl: 8, grants: { pp: 8, adeptSkillChoice: true } },
      { lvl: 9, features: [{ name: "Truthseeking Orb", action: ">>", text: "Signature 3rd level clairvoyance power. Attack roll (+Adept dice) +Mind modifier vs a creature within 25ft, ignoring armor/power/item/environmental AR bonuses. On a hit: 5d12 unknown damage." }] },
      { lvl: 10, grants: { ap: 1 } },
      { lvl: 11, features: [{ name: "Truthseeking Orb", text: "Deals 5d12 +Mind modifier unknown damage." }] },
      { lvl: 12, grants: { adeptSkillChoice: true } },
    ],
  },
  {
    name: "Riskrunner",
    blurb: "One of the luckiest people in the galaxy — chance always has their back.",
    save: "Spiritual",
    weapons: ["Blasters", "Bows"],
    hitDie: "d10", hitDieAttr: "Luck",
    resource: "slots",
    slotTable: SLOT_TABLE_A,
    progression: [
      { lvl: 1, features: [{ name: "Fortunate Shot", text: "Expend a 1st level power slot to add half your Luck modifier to your next attack roll with a Blaster or Bow." }] },
      { lvl: 2, grants: { ap: 1 } },
      { lvl: 3, features: [{ name: "Fortunate Shot", text: "On a successful attack roll with this ability, add half your Luck modifier to the damage roll." }] },
      { lvl: 4, grants: { adeptSkillChoice: true } },
      { lvl: 5, features: [
        { name: "Fortunate Shot", text: "Expend a 2nd level power slot to add your whole Luck modifier to the attack roll instead of half." },
        { name: "Fortunate Save", text: "Expend a 2nd level power slot to add half your Luck modifier to your next saving roll." },
      ] },
      { lvl: 6, grants: { ap: 1 } },
      { lvl: 7, features: [{ name: "Fortunate Shot", text: "On success, add your whole Luck modifier to the damage roll instead of half." }] },
      { lvl: 8, grants: { adeptSaveChoice: ["Physical", "Mental"] } },
      { lvl: 9, features: [
        { name: "Fortunate Shot", text: "On a critical success, the target is unlucky for 1 minute (subtracts half your Luck modifier from all their rolls)." },
        { name: "Fortunate Save", text: "Expend a 3rd level power slot to add your whole Luck modifier to the saving roll instead of half." },
      ] },
      { lvl: 10, grants: { attrRaise: true } },
      { lvl: 11, features: [{ name: "Fortunate Shot", text: "Unlucky creatures subtract your whole Luck modifier instead of half." }] },
      { lvl: 12, grants: { adeptSkillChoice: true } },
    ],
  },
  {
    name: "Songbird",
    blurb: "A musician communed with by unseen spirits, channeling Sorcery through song.",
    save: "Spiritual",
    weapons: ["Blasters", "Blades"],
    hitDie: "d8", hitDieAttr: "Spirit",
    resource: "powerpoints",
    slotTable: SLOT_TABLE_B,
    progression: [
      { lvl: 1, features: [{ name: "Inspiration", action: ">>", text: "Signature 1st level sorcery power. A friendly creature within 15ft is inspired for 1 minute, gaining a non-expendable 1st level power slot." }] },
      { lvl: 2, grants: { pp: 2, adeptSkillChoice: true } },
      { lvl: 3, features: [{ name: "Inspiration", text: "When an inspired creature succeeds on any roll, they receive 1d4 healing." }] },
      { lvl: 4, grants: { pp: 4, adeptSaveChoice: ["Physical", "Mental"] } },
      { lvl: 5, features: [
        { name: "Inspiration", text: "Cast with a 2nd level slot: the inspired creature gets an additional action." },
        { name: "Disconnection", action: ">>", text: "Signature 2nd level sorcery power. Hostile creature within 15ft makes a Spiritual save or is disconnected for 1 minute (one action instead of two)." },
      ] },
      { lvl: 6, grants: { pp: 6, attrRaise: true } },
      { lvl: 7, features: [{ name: "Inspiration", action: ">", text: "Cast with a 3rd level slot: costs one less action." }] },
      { lvl: 8, grants: { pp: 8, ap: 1 } },
      { lvl: 9, features: [
        { name: "Inspiration", text: "Successful rolls from an inspired creature grant 2d4 +Spirit modifier healing." },
        { name: "Magnum Opus", action: ">>", text: "Signature 3rd level sorcery power. All friendly creatures within 15ft are inspired; hostile creatures within 15ft make a Spiritual save or take 6d6 radiant damage." },
      ] },
      { lvl: 10, grants: { adeptSkillChoice: true } },
      { lvl: 11, features: [{ name: "Magnum Opus", text: "Deals 6d6 +Spirit modifier radiant damage." }] },
      { lvl: 12, grants: { adeptSkillChoice: true } },
    ],
  },
  {
    name: "Specialist",
    blurb: "An experienced mercenary who's used every trick to break into and out of the most secure places in the Grand Galaxy, training with cutting-edge technology.",
    save: "Physical",
    weapons: ["Blades", "Blasters"],
    hitDie: "d10", hitDieAttr: "Body",
    resource: "none",
    slotTable: null,
    note: "Unlike other paths, all abilities here and their subsequent upgrades can only be used once (per long rest).",
    progression: [
      { lvl: 1, features: [{ name: "Aptitude", text: "Become Adept with a skill check of your choice." }] },
      { lvl: 2, grants: { ap: 1 } },
      { lvl: 3, features: [{ name: "Mentorship", text: "Outside of combat, train another player for an hour. After the session is over, the other player becomes Adept with a skill check of their choice." }] },
      { lvl: 4, grants: { adeptSkillChoice: true } },
      { lvl: 5, features: [
        { name: "Mastery", text: "Outside of combat, train yourself for an hour. After the session is over, turn one of your Inept skills into an Adept skill check." },
        { name: "Aptitude", text: "Become Adept with a saving roll of your choice." },
      ] },
      { lvl: 6, grants: { attrRaise: true } },
      { lvl: 7, features: [
        { name: "Aptitude", text: "Become Adept with a skill check of your choice." },
        { name: "Mentorship", text: "Outside of combat, train another player for an hour. After the session is over, the other player becomes Adept with a saving roll of their choice." },
      ] },
      { lvl: 8, grants: { adeptSaveChoice: ["Mental", "Spiritual"] } },
      { lvl: 9, features: [{ name: "Mastery", text: "Outside of combat, train yourself for an hour. After the session is over, turn one of your Inept skills into an Adept skill check." }] },
      { lvl: 10, grants: { attrRaise: true, ap: 1 } },
      { lvl: 11, features: [
        { name: "Mentorship", text: "Outside of combat, train another player for an hour. After the session is over, the other player turns one of their Inept skills into an Adept skill check." },
        { name: "Aptitude", text: "Receive an additional Advancement point." },
        { name: "Mentorship", text: "Outside of combat, train another player for an hour. After the session is over, the other player becomes Adept with a skill check of their choice." },
      ] },
      { lvl: 12, grants: { adeptSkillChoice: true } },
    ],
  },
  {
    name: "Spiritualist",
    blurb: "You are able to focus your mystical powers.",
    save: "Spiritual",
    weapons: ["Bows", "Polearms"],
    hitDie: "d8", hitDieAttr: "Spirit",
    resource: "powerpoints",
    slotTable: SLOT_TABLE_B,
    progression: [
      { lvl: 1, grants: { pp: "halfSpirit" }, features: [{ name: "Spiritual Powershape: Accuracy", text: "When you cast a sorcery or technomancy power that requires an attack roll, expend an additional power slot of the same level to increase its accuracy — the attack roll becomes an automatic success." }] },
      { lvl: 2, grants: { ap: 1 } },
      { lvl: 3, features: [{ name: "Spiritual Powershape: Damage", text: "When you cast a sorcery or technomancy power that deals damage, expend an additional power slot of the same level to increase its potency — add your Adept dice to the subsequent damage roll." }] },
      { lvl: 4, grants: { pp: 4, adeptSaveChoice: ["Physical", "Mental"] } },
      { lvl: 5, features: [{ name: "Spiritual Powershape: Duration", text: "When you cast a sorcery or technomancy power that has a duration, expend an additional power slot of the same level to give it the concentration trait. When a power has the concentration trait, you can use an action to refresh its duration." }] },
      { lvl: 6, grants: { pp: 6, ap: 1 } },
      { lvl: 7, features: [{ name: "Spiritual Powershape: Save", text: "When a hostile creature makes a Spiritual saving roll against you, expend a 2nd level power slot to subtract your Adept dice from their roll." }] },
      { lvl: 8, grants: { pp: 8, attrRaise: true } },
      { lvl: 9, features: [{ name: "Spiritual Powershape: Save", text: "This now applies when a hostile creature makes a Physical, Mental, or Spiritual saving roll against you." }] },
      { lvl: 10, grants: { adeptSkillChoice: true } },
      { lvl: 11, features: [{ name: "Spiritual Powershape: Presence", text: "When a friendly creature makes a saving roll, expend a 3rd level power slot to add your Adept dice to their roll." }] },
      { lvl: 12, grants: { pp: "halfSpirit" } },
    ],
  },
];

/* --------------------------------- PATHWAYS -------------------------------- */
/* Subclasses. Every path has two. Pathway features unlock at even levels
   (2/4/6/8/10/12) on top of whatever the parent path grants at that level. */
const PATHWAYS = [
  // ===== BIOWEAPON =====
  {
    name: "Warmade", parentPath: "Bioweapon",
    blurb: "A bioweapon cybernetically enhanced for combat — artificial limbs built to destroy enemies, but at a cost.",
    progression: [
      { lvl: 2, features: [{ name: "Grapple Point", action: ">", text: "Attack roll (+Adept dice) +Agility vs a target within 30ft: shoot a plasma-wired hook from your arm. On a hit, 2d6 piercing damage and a Physical save or the target is dragged within 5ft of you." }] },
      { lvl: 4, features: [
        { name: "Grapple Point", text: "While enraged, attempt to hook an additional target with this ability (secondary attack roll suffers a \u22122 penalty)." },
        { name: "Shock", action: "<", text: "Reaction to taking damage for the first time since becoming enraged: unleash electricity. All targets within 10ft make a Physical save or take 3d8 ion damage." },
      ] },
      { lvl: 6, features: [
        { name: "Grapple Point", text: "Deals 2d6 +Body modifier piercing damage normally, and 3d6 +Body modifier piercing or plasma damage while enraged." },
        { name: "Shock", text: "After using this ability, you're shielded for 1 minute. While shielded, incoming plasma, ion, and sonic damage is halved." },
      ] },
      { lvl: 8, features: [{ name: "Focused Fire", action: ">>", text: "While enraged, lock onto an enemy and fire a flurry of bullets. Three attack rolls (+Adept dice) +Agility vs a single target; each hit deals 2d10 fire damage. Mental save against your Physical SL or the target attacks you on its next turn." }] },
      { lvl: 10, features: [
        { name: "Reforge", action: ">>", text: "While below half health and enraged, force your cybernetics to repair your wounds. Make a Technology check; the result is added to your current health." },
        { name: "Shock", text: "No longer requires being enraged to use, but can't be used while shielded." },
      ] },
      { lvl: 10, features: [{ name: "Reforge", text: "Upon using this ability, become reforged for 1 minute. While reforged, incoming slashing, piercing, and bludgeoning damage is halved." }] },
      { lvl: 12, features: [
        { name: "Focused Fire", text: "If used while not enraged, make two attack rolls (+Adept dice) +Agility against a single target instead of three. Deals 3d10 fire damage per hit." },
        { name: "Reforge", text: "When making the Technology check for this ability, roll twice and use the higher result." },
      ] },
    ],
  },
  {
    name: "Witchmade", parentPath: "Bioweapon",
    blurb: "A bioweapon abducted and experimented on by the Shadow Covenant, turned into a destructive force from the Below.",
    progression: [
      { lvl: 2, features: [{ name: "Intimidating Presence", text: "Horns and spikes emerge from your body. When you make an Intimidation check, roll twice and use the higher result." }] },
      { lvl: 4, features: [
        { name: "Immolation", action: ">", text: "While enraged, set fire to the area around you. All creatures within 10ft make a Spiritual save against your Physical SL or take 2d8 fire and 2d6 necrotic damage (constructs auto-fail and take only the fire damage). Ends your enraged condition." },
        { name: "Intimidating Presence", text: "While enraged, attempt to taunt a creature within 15ft. Mental save against your Physical SL or they become provoked for 1 minute, focusing their attacks on you." },
      ] },
      { lvl: 6, features: [
        { name: "Immolation", text: "If cast using two actions, it no longer ends your enraged condition." },
        { name: "Intimidating Presence", text: "Using this on an already-provoked creature makes them haunted instead (lasts until healed). While haunted, they can attack whoever they want, but take 2d4 psychic damage if they damage a target that isn't you." },
      ] },
      { lvl: 8, features: [
        { name: "Abyssal Flame", action: ">", text: "Hurl a mote of black fire at an enemy within 25ft. While enraged, attack roll (+Adept dice) +Agility: on a hit, 2d8 +Spirit modifier fire damage (+2d6 +Spirit modifier necrotic if a creature; 2d10 +Spirit modifier fire if a construct)." },
        { name: "Immolation", text: "Deals 2d10 +Spirit modifier fire and 2d8 +Spirit modifier necrotic damage (2d12 +Spirit modifier fire against constructs)." },
      ] },
      { lvl: 10, features: [
        { name: "Intimidating Presence", text: "When a haunted creature attacks a target that isn't you, they take 2d6 necrotic damage." },
        { name: "Immolation", text: "After using this ability, become inscribed for 1 minute. While inscribed, incoming necrotic, radiant, and unknown damage is halved." },
      ] },
      { lvl: 12, features: [{ name: "Abyssal Flame", text: "When this ability kills a haunted creature, their body implodes. All creatures within 5ft make a Spiritual save against you or become haunted for 1 minute." }] },
    ],
  },
  // ===== BLOODBLADE =====
  {
    name: "Affliction", parentPath: "Bloodblade",
    blurb: "A veteran bloodblade who bends their bloodstream to poison others and spread disease.",
    progression: [
      { lvl: 2, features: [{ name: "Venomize", text: "Imbue your bloodstream with pure poison — the next time Sanguine Strike is used, it also deals 2d6 poison damage." }] },
      { lvl: 4, features: [
        { name: "Venomize", text: "After a creature takes poison damage from Sanguine Strike, Physical save against you or they're poisoned for 1 minute (3d4 poison damage at the start of their turn)." },
        { name: "Infection", action: ">", text: "Expend a 2nd level power slot and select a poisoned creature within 25ft. Physical save against you or they become infected for 1 minute (a point of Exhaustion at the start of their turn)." },
      ] },
      { lvl: 6, features: [
        { name: "Venomize", text: "Sanguine Strike or Sanguine Shot can be imbued with pure poison — the next use also deals 2d6 +Body modifier poison damage." },
        { name: "Disease", action: "<", text: "When an infected or poisoned creature dies before the condition expires, the illness contaminates the air. Creatures within 5ft make a Physical save against you or become diseased for 1 minute (vulnerability score of 2 against poison)." },
      ] },
      { lvl: 8, features: [
        { name: "Contagion", action: ">>", text: "Expend a 3rd level power slot and attempt to manipulate the bloodstream of a bleeding creature within 10ft. Physical save against you or they become poisoned, infected, and diseased for 1 minute." },
        { name: "Spread Disease", action: "<", text: "Reaction to taking damage: spray blood into the air. Creatures within 10ft make a Physical save against you or become diseased for 1 minute." },
      ] },
      { lvl: 10, features: [
        { name: "Venomize", text: "A poisoned creature must be healed to overcome the condition (unless poisoned via Contagion)." },
        { name: "Infection", text: "An infected creature must be healed to overcome the condition (unless infected via Contagion). Infected creatures also receive two points of Exhaustion at the start of their turn instead of one." },
        { name: "Disease", text: "A diseased creature must be healed to overcome the condition (unless diseased via Contagion)." },
      ] },
      { lvl: 12, features: [{ name: "Contagion", text: "Creatures poisoned, infected, or diseased through this ability must be healed to overcome those conditions." }] },
    ],
  },
  {
    name: "Sanguination", parentPath: "Bloodblade",
    blurb: "A rare breed of bloodblade whose blood isn't their own — physically tied to the Below and its endless hunger.",
    progression: [
      { lvl: 2, features: [{ name: "Leech", action: ">>", text: "Expend a 1st level power slot and attempt to drain life from an enemy within 15ft. Physical save against you or they take 2d8 +Body modifier slashing damage; half the outcome is added to your current health." }] },
      { lvl: 4, features: [{ name: "Leech", text: "Against a bleeding creature, the Physical save is made twice, using the lower result." }] },
      { lvl: 6, features: [
        { name: "Bloodletting", action: "<", text: "Expend a 2nd level power slot as a reaction to taking damage: submit to the cries of the Below and become undead for 1 minute. While undead, healing you receive is doubled, but you're weak against radiant and unknown damage." },
        { name: "Leech", text: "While undead, damage rolls with this ability are made twice, using the higher result." },
      ] },
      { lvl: 8, features: [
        { name: "Bloodletting", text: "While undead, you're no longer weak against unknown damage." },
        { name: "Feral Friend", action: ">", text: "Expend a 3rd level power slot and summon a vampyr in an unoccupied space within 5ft. GM-controlled, one action, focuses enemies close to you. Lasts 1 minute." },
      ] },
      { lvl: 10, features: [
        { name: "Leech", text: "Deals 3d8 +Body modifier slashing damage normally, and 3d10 +Body modifier against bleeding creatures." },
        { name: "Bloodletting", text: "While undead, you're no longer weak against radiant damage." },
        { name: "Feral Friend", text: "Your vampyr has two actions instead of one and lasts as long as you'd like (costs an action to dismiss)." },
      ] },
      { lvl: 12, features: [
        { name: "Leech", text: "Damage rolls are made twice, using the higher result. While undead, made three times, using the highest." },
        { name: "Bloodletting", text: "While undead, you're immune to necrotic damage." },
      ] },
    ],
  },
  // ===== HOTSHOT =====
  {
    name: "Scoundrel", parentPath: "Hotshot",
    blurb: "A smuggler who's refined their charm — when things hit the fan, combat becomes a social playground.",
    progression: [
      { lvl: 2, features: [
        { name: "Roguish Charm", action: "<", text: "Reaction to taking damage: attempt to charm the attacker. Persuasion check against their AR; on a success, they're charmed for 1 minute (ignore you, attack others; attacking a charmed being ends the effect early)." },
        { name: "Dual Wielder", text: "When using Flurry with two pistols or handbows, make the damage roll twice and use the higher result." },
      ] },
      { lvl: 4, features: [
        { name: "Roguish Charm", text: "When attacking a charmed being, add half your Spirit modifier to the attack roll." },
        { name: "Dual Wielder", text: "When using Flurry with two pistols or handbows, add half your Agility modifier to the damage roll." },
      ] },
      { lvl: 6, features: [
        { name: "Roguish Charm", text: "A charmed being remains charmed until you attack them." },
        { name: "Dual Wielder", text: "When using Flurry with two pistols or handbows, add your whole Agility modifier to the damage roll instead of half." },
      ] },
      { lvl: 8, features: [
        { name: "Roguish Charm", text: "After attacking a charmed being, take the Defusal action at the same time. Deception check — on a success, the being remains charmed." },
        { name: "Dual Wielder", text: "When critically succeeding on a Flurry attack roll, add your Agility modifier to the damage roll before doubling it." },
        { name: "Showoff", action: ">>", text: "Expend a 3rd level power slot and attempt to impress your enemies. Performance check against the AR of every hostile creature within 45ft. On a success, a creature is impressed for 1 minute (subtracts half your Spirit modifier from attack rolls)." },
      ] },
      { lvl: 10, features: [{ name: "Roguish Charm", text: "Can be used as an action instead of a reaction." }] },
      { lvl: 12, features: [
        { name: "Roguish Charm", text: "When making the Persuasion or Deception check for this ability, roll twice and use the higher result." },
        { name: "Showoff", text: "Impressed creatures subtract your whole Spirit modifier from attack rolls instead of half." },
      ] },
    ],
  },
  {
    name: "Hexslinger", parentPath: "Hotshot",
    blurb: "A hotshot who ventured into an unkown part of space — the weapons wielded now are harbingers of a strange power.",
    progression: [
      { lvl: 2, features: [{ name: "Hexing Mark", action: ">", text: "After dealing damage to a creature, consume another action and attempt to hex them. Spiritual save against your Physical SL or they're hexed for 1 minute (subtracts half your Spirit modifier from Spiritual saving rolls). Only one creature can be hexed at a time." }] },
      { lvl: 4, features: [
        { name: "Hexing Mark", text: "When used with a 1st level power slot, the target automatically fails the save and becomes hexed." },
        { name: "Slowing Shot", action: ">", text: "Expend a 2nd level power slot; attack roll (+Adept dice) +Agility vs a target within 30ft. On a hit, 2d8 +Spirit modifier necrotic damage and a Spiritual save against your Physical SL or slowed for 1 minute (movement halved; only 10ft/turn if also hexed). Only one creature can be slowed at a time." },
      ] },
      { lvl: 6, features: [
        { name: "Hexing Mark", action: "<", text: "Can be used as a reaction to taking damage, but must target the attacker." },
        { name: "Slowing Shot", text: "A hexed and slowed creature can only use 5ft of movement per turn." },
      ] },
      { lvl: 8, features: [
        { name: "Hexing Mark", text: "When the hexed condition ends, the creature takes 2d8 unknown damage." },
        { name: "Exhaustive Shot", action: ">>", text: "Expend a 3rd level power slot; attack roll (+Adept dice) +Agility vs a target within 30ft. On a hit, 3d8 +Spirit modifier necrotic damage and a Spiritual save against your Physical SL or exhausted for 1 minute (two points of Exhaustion at the start of their turn). Only one creature can be exhausted at a time." },
        { name: "Slowing Shot", text: "A hexed creature that's also slowed has their abilities and powers cost an extra action." },
      ] },
      { lvl: 10, features: [
        { name: "Hexing Mark", text: "Two creatures can be hexed at the same time." },
        { name: "Slowing Shot", text: "Two creatures can be slowed at the same time." },
      ] },
      { lvl: 12, features: [{ name: "Hexing Mark", text: "Deals 2d10 +Spirit modifier unknown damage when the condition expires." }] },
    ],
  },
  // ===== MAVERICK =====
  {
    name: "Beastmaster", parentPath: "Maverick",
    blurb: "A maverick who's taken to taming beasts and bringing them into battle, finding better company in creatures than people.",
    progression: [
      { lvl: 2, features: [
        { name: "Tame Beast", action: ">>", text: "Attempt to handle a beast within 25ft (it must be by itself). Performance, Persuasion, or Technique check (DR set by the GM based on the beast's level). On a fail, it runs away; on a success, it's tamed." },
        { name: "Unleash", action: ">", text: "With a tamed beast, prepare it for battle. It becomes your ally with one action, GM-controlled for now. Only one beast at a time." },
      ] },
      { lvl: 4, features: [
        { name: "Tame Beast", text: "If retrying on a creature you've already attempted to tame, make the check twice and use the higher result." },
        { name: "Dismiss", action: "<", text: "Reaction to your beast taking damage: force it to flee from combat." },
      ] },
      { lvl: 6, features: [{ name: "Beast Medicine", action: ">", text: "Heal your beast's injuries in combat (must be within 5ft). Once per long rest. On use, the beast receives 3d8 healing." }] },
      { lvl: 8, features: [
        { name: "Tame Beast", text: "Your beast has two actions instead of one." },
        { name: "Issue Command", action: ">", text: "The bond with your beast has improved — issue it a command (Attack, Move, Near, Run, or Wait) and it follows your orders to the best of its ability." },
      ] },
      { lvl: 10, features: [
        { name: "Beast Medicine", text: "Grants 4d8 healing." },
        { name: "Issue Command", text: "When your beast attacks the target you've commanded it against, its first attack roll is made twice, using the higher result." },
      ] },
      { lvl: 12, features: [
        { name: "Tame Beast", text: "Your beast's maximum health is increased by 25 points." },
        { name: "Issue Command", text: "When your beast damages the target you've commanded it against, the roll is made twice, using the higher result." },
      ] },
    ],
  },
  {
    name: "Deathbringer", parentPath: "Maverick",
    blurb: "A maverick who's slain men and monsters alike to make a living — a killer whose work is far from over.",
    progression: [
      { lvl: 2, features: [{ name: "Stalker's Presence", text: "When a beast makes an attack roll, saving roll, or skill check within 5ft of you, they make the roll twice and use the lower result." }] },
      { lvl: 4, features: [
        { name: "Stalker's Presence", text: "Range increases to 10ft." },
        { name: "First Blood", text: "When dealing damage to an unharmed target, make the damage roll twice and use the higher result." },
      ] },
      { lvl: 6, features: [
        { name: "Stalker's Presence", text: "Now works on beings as well as beasts, and range increases to 15ft." },
        { name: "First Blood", text: "After dealing damage to a previously-unharmed target, if it's a creature, Physical save against you or a wound opens and they bleed for 1 minute (2 HP lost per action)." },
      ] },
      { lvl: 8, features: [
        { name: "Reaper's Mark", text: "Upon dealing damage to a creature, claim it as marked (until someone besides you damages it) — your other abilities are more effective against marked creatures." },
        { name: "Stalker's Presence", text: "While a marked creature is in range, it makes its saving rolls, attack rolls, and skill checks three times, using the lowest." },
        { name: "Fatal Blow", action: ">>", text: "Attack roll against a marked creature; on a hit, the damage roll is made three times, using the highest. If they survive, vulnerability score of 2 against slashing and piercing damage for 1 minute." },
      ] },
      { lvl: 10, features: [{ name: "First Blood", text: "When this ability makes a creature bleed, it lasts until healed (3 HP lost per action)." }] },
      { lvl: 12, features: [
        { name: "First Blood", text: "Bleeding creatures lose 4 HP per action instead of 3." },
        { name: "Execution", action: "<", text: "Attempt to finish off an enemy: as a reaction, attack a bleeding or marked creature within weapon range. On success, the reaction is refunded and you can attempt to finish off another enemy in range." },
      ] },
    ],
  },
  // ===== MENTALIST =====
  {
    name: "Clairvoyant", parentPath: "Mentalist",
    blurb: "A Mentalist more attuned to their own psyche than others, able to overwhelm and destroy the minds of enemies.",
    progression: [
      { lvl: 2, features: [{ name: "Psychic Slice", action: ">>", text: "Signature 1st level clairvoyance power. Two attack rolls against a creature within 15ft as you dash into and out of their mind. 2d6 psychic damage on the first hit, 2d8 slashing on the second." }] },
      { lvl: 4, features: [
        { name: "Psychic Slice", text: "Cast with a 2nd level slot: 2d6 +Mind modifier psychic on the first hit, 2d8 +Mind modifier slashing on the second." },
        { name: "Telekinetic Field", action: "<", text: "Signature 2nd level clairvoyance power. Reaction to taking damage: a psychic shield for 1 minute. Attackers make a Mental save against you or take 2d10 +Mind modifier force damage and are moved 10ft, or 4d6 +Mind modifier psychic damage." },
      ] },
      { lvl: 6, features: [
        { name: "Psychic Slice", text: "Can cost one less action to cast, but becomes exhaustive." },
        { name: "Pyrokinetic Field", action: "<", text: "Signature 2nd level clairvoyance power. Reaction to taking damage: a fiery shield for 1 minute. Attackers make a Physical save against your Mental SL or take 4d6 +Mind modifier fire damage and burn for 1 minute (2d8 fire at the start of their turn)." },
      ] },
      { lvl: 8, features: [
        { name: "Psychic Slice", text: "Cast with a 3rd level slot: 3d6 +Mind modifier psychic on the first hit, 3d8 +Mind modifier slashing on the second." },
        { name: "Telekinetic Field", text: "Cast with a 3rd level slot: creatures within 10ft make a Mental save on expiration or take 3d4 +Mind modifier force and 3d6 +Mind modifier psychic damage." },
        { name: "Pyrokinetic Field", text: "Cast with a 3rd level slot: targets burn a minute longer and take 3d8 fire damage at the start of their turn." },
        { name: "Psychic Storm", action: ">>", text: "Signature 3rd level clairvoyance power. Fire psychic strands in a 15ft cone. Physical save against your Mental SL or 4d10 psychic damage. Exhaustive." },
      ] },
      { lvl: 10, features: [{ name: "Psychic Storm", text: "Deals 4d10 +Mind modifier psychic damage against creatures weak or vulnerable to psychic damage; can cost one less action but grants three points of Exhaustion instead of one." }] },
      { lvl: 12, features: [{ name: "Psychic Storm", text: "When cast with one action, grants two points of Exhaustion instead of three." }] },
    ],
  },
  {
    name: "Ordinator", parentPath: "Mentalist",
    blurb: "A Mentalist more attuned to their Vessel than others, calling on its power directly.",
    progression: [
      { lvl: 2, features: [{ name: "Vessel Weapon", action: ">>", text: "Signature 1st level ordination power. Summon your Vessel's auto-cannon and fire energy rounds in a 15ft cone. Physical save against your Mental SL or 3d8 plasma, ion, or sonic damage. Exhaustive." }] },
      { lvl: 4, features: [{ name: "Vessel Weapon", text: "Cast with a 2nd level slot to instead summon a displacer or missile launcher. Displacer: attack roll (+Adept dice) +Mind vs a target within 15ft, 3d10 force damage and pushed 20ft. Missile launcher: attack roll (+Adept dice) +Mind vs a target within 40ft, 2d10 bludgeoning + 2d10 fire damage." }] },
      { lvl: 6, features: [
        { name: "Vessel Weapon", text: "Can cost one less action to cast, but grants three points of Exhaustion instead of one." },
        { name: "Ordination Presence", action: ">", text: "When a crew member is using the Vessel's weapons, expend a 2nd level power slot to aid them — they add your Vessel's applicable modifiers and Adept dice to the attack roll instead of their own." },
        { name: "Salvation", action: "<", text: "Signature 2nd level ordination power. Reaction to your Vessel reaching 0 HP: the first Emergency roll it makes is an automatic success." },
      ] },
      { lvl: 8, features: [
        { name: "Vessel Weapon", text: "Cast with a 3rd level slot to instead summon a disintegrator: attack roll (+Adept dice) +Mind vs a target within 50ft, 5d10 unknown damage." },
        { name: "Vessel Power", action: ">>", text: "Signature 3rd level ordination power. Borrow your Vessel's primary ability. Two attack rolls (+Adept dice) +Mind vs a creature within 30ft: 3d10 +Mind modifier piercing/unknown/necrotic/radiant on the first hit, 3d8 +Mind modifier slashing/unknown/necrotic/radiant on the second (type depends on your Vessel's species). Exhaustive." },
      ] },
      { lvl: 10, features: [
        { name: "Vessel Weapon", text: "When cast with one action, grants two points of Exhaustion instead of three." },
        { name: "Vessel Power", text: "Can cost one less action to cast, but grants three points of Exhaustion instead of one." },
        { name: "Salvation", text: "Cast with a 3rd level slot: the first and second Emergency rolls your Vessel makes automatically succeed." },
      ] },
      { lvl: 12, features: [
        { name: "Vessel Weapon", text: "Adds half your Mind modifier to the damage roll." },
        { name: "Vessel Power", text: "When cast with one action, grants two points of Exhaustion instead of three." },
      ] },
    ],
  },
  // ===== OTHERWORLDER =====
  {
    name: "Timewalker", parentPath: "Otherworlder",
    blurb: "An otherworlder able to see through time in bursts, manipulating the timestream in small ways.",
    progression: [
      { lvl: 2, features: [{ name: "Divination", action: ">", text: "Signature 1st level clairvoyance power. Outside of combat, see hundreds of outcomes for 1 hour — while divining, add a d4 to every skill check you attempt." }] },
      { lvl: 4, features: [
        { name: "Divination", text: "Can be cast onto another player within 15ft (only one player can be divining at a time)." },
        { name: "Rewind", action: ">>", text: "Signature 2nd level clairvoyance power. After casting, make your next skill check or saving roll three times, using the highest result." },
      ] },
      { lvl: 6, features: [
        { name: "Divination", text: "Add a d6 to skill checks instead of a d4." },
        { name: "Rewind", action: "<", text: "Can be cast as a reaction to taking damage — the attacker makes their current attack roll two more times, using the lower result." },
      ] },
      { lvl: 8, features: [
        { name: "Divination", text: "You and one other player can be divining at the same time; while divining, roll the d6 twice and use the higher result." },
        { name: "Rewind", text: "Instead of rerolling a skill check or saving roll, choose to make your next damage roll three times, using the highest result." },
        { name: "Return", action: ">>", text: "Signature 3rd level clairvoyance power. Take an ailment from the past and bring it into the present. Select a hostile creature within 30ft; if bleeding, poisoned, haunted, exhausted, sickened, or fearful within the last hour, reapply that condition exactly as it was." },
      ] },
      { lvl: 10, features: [
        { name: "Rewind", text: "This ability can instead be cast as a reaction to taking damage." },
        { name: "Return", text: "The reapplied condition deals 3d10 unknown damage after it expires; can also reapply charmed, diseased, infected, slowed, and disconnected." },
      ] },
      { lvl: 12, features: [{ name: "Return", text: "Can be cast onto allies to bring back positive effects (shielded, inscribed, inspired, rageful, or undead) from the past." }] },
    ],
  },
  {
    name: "Shapeshifter", parentPath: "Otherworlder",
    blurb: "An otherworlder whose ties to every beast and monster in the galaxy let them transform into deadly creatures.",
    progression: [
      { lvl: 2, features: [{ name: "Form Change: Hound", action: ">", text: "Signature 1st level sorcery power. Transform into a hound." }, { name: "Shapeshifting", text: "You're in complete control of a transformation for 1 minute. Only one form change per long rest. Damage taken while transformed is separate from your own health and doesn't carry over. Reaching 0 health while transformed reverts you with 1 HP remaining. The GM provides the statblock." }] },
      { lvl: 4, features: [
        { name: "Shapeshifting", text: "Two form changes can be used per long rest." },
        { name: "Form Change: Hound", action: ">>", text: "Transform into a dire hound instead (costs two actions, as it's more powerful)." },
        { name: "Form Change: Vantra", action: ">", text: "Signature 1st level sorcery power. Transform into a vantra." },
      ] },
      { lvl: 6, features: [
        { name: "Shapeshifting", text: "After a transformation expires, receive the resistances of the creature you turned into for 1 minute." },
        { name: "Form Change: Dargada", action: ">", text: "Signature 2nd level sorcery power. Transform into a dargada." },
        { name: "Form Change: Mantor", action: ">>", text: "Signature 2nd level sorcery power. Transform into a mantor." },
      ] },
      { lvl: 8, features: [
        { name: "Shapeshifting", text: "Three form changes can be used per long rest." },
        { name: "Revert", action: "<", text: "Reaction to taking damage: end your transformation prematurely." },
        { name: "Form Change: Wrenghoul", action: ">", text: "Signature 3rd level sorcery power. Transform into a wrenghoul." },
      ] },
      { lvl: 10, features: [
        { name: "Shapeshifting", text: "Transformations last a minute longer." },
        { name: "Form Change: Goliath", action: ">>", text: "Signature 3rd level sorcery power. Transform into a goliath." },
      ] },
      { lvl: 12, features: [{ name: "Form Change: Abberanth", action: ">>", text: "Signature 3rd level sorcery power. Transform into an abberanth." }] },
    ],
  },
  // ===== RISKRUNNER =====
  {
    name: "Wildcard", parentPath: "Riskrunner",
    blurb: "A riskrunner whose luck has turned into an uncontrollable force — punishing and rewarding in equal, chaotic measure.",
    progression: [
      { lvl: 2, features: [{ name: "Random Effect", text: "After using Fortunate Shot, roll a d4 (your random dice). 1: if the target was a creature, they take extra damage equal to your Luck score. 2: your movement is reduced by 10ft for 1 minute. 3: make a Fortuity check — half the outcome is added to your current health. 4: your luck backfires — subtract your Luck score from your current health." }] },
      { lvl: 4, features: [
        { name: "Random Effect", text: "Your random dice becomes a d6, adding: 5: your next attack roll, skill check, or saving roll is a critical failure. 6: your next attack roll, skill check, or saving roll is a critical success." },
        { name: "Reverse", text: "Expend a 2nd level power slot to reroll your random dice — you must use the next result, no matter what." },
      ] },
      { lvl: 6, features: [{ name: "Random Effect", text: "Your random dice becomes a d8, adding: 7: receive two points of Exhaustion. 8: if the Fortunate Shot target was a creature, they receive two points of Exhaustion." }] },
      { lvl: 8, features: [{ name: "Random Effect", text: "Your random dice becomes a d10, adding: 9: suffer a vulnerability score of 4 against all damage types for 1 minute. 10: the Fortunate Shot target suffers a vulnerability score of 4 against all damage types for 1 minute." }] },
      { lvl: 10, features: [{ name: "Random Effect", text: "Your random dice becomes a d12, adding: 11: you're reduced to 0 HP and must make Mercy rolls to survive. 12: the Fortunate Shot target loses half their current health." }] },
      { lvl: 12, features: [{ name: "Lucky Choice", action: ">>", text: "Expend a 3rd level power slot and choose a number between 1 and 12 — your next random dice roll uses that effect instead." }] },
    ],
  },
  {
    name: "Fatemaker", parentPath: "Riskrunner",
    blurb: "A riskrunner whose luck affects others more than themself — Lady Luck has an eye on harming foes and aiding allies alike.",
    progression: [
      { lvl: 2, features: [
        { name: "Lucky Presence", action: ">", text: "Expend a 1st level power slot to become lucky for 1 minute. While lucky, allies within 10ft add half your Luck modifier to skill checks made in range." },
        { name: "Fatal Focus", action: ">", text: "Expend a 1st level power slot to take control over your own luck — the next time Fortunate Shot is used, make the attack roll twice and use the higher result." },
      ] },
      { lvl: 4, features: [
        { name: "Lucky Presence", text: "Allies within range add half your Luck modifier to saving rolls too." },
        { name: "Unlucky Presence", action: ">", text: "Expend a 2nd level power slot to become favored for 1 minute. While favored, hostile creatures within 10ft subtract half your Luck modifier from skill checks made in range." },
      ] },
      { lvl: 6, features: [
        { name: "Lucky Presence", text: "Allies within range add half your Luck modifier to attack rolls too." },
        { name: "Unlucky Presence", text: "Hostile creatures within range subtract half your Luck modifier from saving rolls too." },
      ] },
      { lvl: 8, features: [
        { name: "Lucky Presence", text: "Allies within range add half your Luck modifier to damage rolls too." },
        { name: "Unlucky Presence", text: "Hostile creatures within range subtract half your Luck modifier from attack rolls too (unless they're unlucky and attacking you)." },
      ] },
      { lvl: 10, features: [
        { name: "Fatal Focus", text: "After using this ability, your next Fortunate Shot attack roll is made three times, using the highest result." },
        { name: "Lucky Presence", text: "Allies within range subtract half your Luck modifier from damage taken." },
        { name: "Unlucky Presence", text: "Hostile creatures within range subtract half your Luck modifier from damage rolls too." },
      ] },
      { lvl: 12, features: [
        { name: "Lucky Presence", text: "Range increases to 20ft." },
        { name: "Unlucky Presence", text: "Range increases to 20ft." },
      ] },
    ],
  },
  // ===== SONGBIRD =====
  {
    name: "Lightbound", parentPath: "Songbird",
    blurb: "A songbird whose restorative and radiant powers have been enhanced by spirits from the Beyond.",
    progression: [
      { lvl: 2, features: [
        { name: "Healing Melody", action: ">", text: "Signature 1st level sorcery power. Play a song of restoration — friendly creatures within 15ft (not you) receive 2d6 healing." },
        { name: "Radiant Blade", action: ">", text: "Signature 1st level sorcery power. Summon a radiant dagger to fight alongside you. When you deal damage to a creature after casting, attack roll (+Adept dice) +Spirit against the same target: on a hit, 3d4 radiant + 1d6 slashing damage. The dagger disappears after dealing damage." },
      ] },
      { lvl: 4, features: [
        { name: "Healing Melody", text: "Cast with a 2nd level slot: heals 2d6 (+Adept dice) +Spirit modifier, including yourself." },
        { name: "Radiant Blade", text: "Cast with a 2nd level slot: summon two daggers instead of one, each dealing 3d4 +Spirit modifier radiant and 2d6 slashing damage. Only one dagger can be used after dealing damage." },
      ] },
      { lvl: 6, features: [
        { name: "Healing Melody", action: "<", text: "Can be cast as a reaction when an ally within 15ft takes damage." },
        { name: "Radiant Blade", text: "After dealing damage, two daggers can be used." },
      ] },
      { lvl: 8, features: [
        { name: "Healing Melody", text: "Cast with a 3rd level slot: friendly creatures within range (including yourself) receive 3d8 (+Adept dice) +Spirit modifier healing." },
        { name: "Radiant Blade", text: "Cast with a 3rd level slot: summon three daggers instead of two, each dealing 4d4 +Spirit modifier radiant and 3d6 slashing damage." },
        { name: "Restoration", action: ">", text: "Signature 3rd level sorcery power. Become restorative for 1 minute. While restorative, healing rolls you make are made twice, using the higher result." },
      ] },
      { lvl: 10, features: [{ name: "Restoration", text: "While restorative, healing rolls are made three times, using the highest result." }] },
      { lvl: 12, features: [
        { name: "Radiant Blade", text: "After dealing damage, three daggers can be used." },
        { name: "Restoration", text: "While restorative, Healing Melody adds your Spirit score to the healing instead of your Spirit modifier." },
      ] },
    ],
  },
  {
    name: "Nightbound", parentPath: "Songbird",
    blurb: "A songbird whose evasive and destructive powers have been enhanced by spirits from the Below.",
    progression: [
      { lvl: 2, features: [
        { name: "Destructive Melody", action: ">>", text: "Signature 1st level sorcery power. Play an ominous song of destruction — hostile creatures within 15ft make a Spiritual save against you or take 2d10 necrotic damage." },
        { name: "Torment Blade", action: ">", text: "Signature 1st level sorcery power. Summon a necrotic shortsword to fight alongside you. When you deal damage to a creature after casting, attack roll (+Adept dice) +Spirit against the same target: on a hit, 3d4 necrotic + 1d8 slashing damage. The sword disappears after dealing damage." },
      ] },
      { lvl: 4, features: [
        { name: "Destructive Melody", text: "Cast with a 2nd level slot: hostile creatures within range that fail the save take 2d10 +Spirit modifier necrotic damage." },
        { name: "Torment Blade", text: "Cast with a 2nd level slot: summon two shortswords instead of one, each dealing 3d4 +Spirit modifier necrotic and 2d8 slashing damage. Only one sword can be used after dealing damage." },
      ] },
      { lvl: 6, features: [
        { name: "Destructive Melody", text: "Costs one less action to cast the first time since a long rest." },
        { name: "Torment Blade", text: "After dealing damage, two shortswords can be used." },
      ] },
      { lvl: 8, features: [
        { name: "Destructive Melody", text: "Cast with a 3rd level slot: hostile creatures within range take 3d12 +Spirit modifier necrotic or unknown damage." },
        { name: "Torment Blade", text: "Cast with a 3rd level slot: summon three shortswords instead of two, each dealing 4d4 +Spirit modifier necrotic/unknown and 3d8 slashing damage, plus 5 extra damage against haunted creatures." },
        { name: "Destruction", action: ">", text: "Signature 3rd level sorcery power. Become volatile for 1 minute. While volatile, necrotic or unknown damage rolls you make are made twice, using the higher result." },
      ] },
      { lvl: 10, features: [{ name: "Torment Blade", text: "After dealing damage, three shortswords can be used." }] },
      { lvl: 12, features: [{ name: "Torment Blade", text: "Deals an extra 10 points of damage against haunted creatures instead of 5." }] },
    ],
  },
  // ===== SPECIALIST =====
  {
    name: "Blackwire", parentPath: "Specialist",
    blurb: "A specialist who controls the flow of battle with nanomachines, injecting technology into creatures to lead them to their destruction.",
    progression: [
      { lvl: 2, features: [
        { name: "Memory", text: "Many abilities consume charges of RAM. Only two charges of RAM can be used per long rest." },
        { name: "Injection", action: ">>", text: "Select a target within 30ft. Physical save against your Mental SL or they become injected for 1 minute — while injected, your blackwire abilities can target them." },
        { name: "Overheat", action: ">", text: "Expend a charge of RAM and select an injected target within 25ft. Mental save against you or they take 2d10 fire damage as your nanites explode." },
      ] },
      { lvl: 4, features: [
        { name: "Memory", text: "Three charges of RAM can be used per long rest." },
        { name: "Injection", text: "Costs one less action to cast." },
        { name: "Overheat", text: "Deals 2d10 +Mind modifier fire damage." },
      ] },
      { lvl: 6, features: [
        { name: "Memory", text: "Four charges of RAM can be used per long rest." },
        { name: "Virus", action: ">", text: "Expend two charges of RAM and select an injected creature within 20ft. Physical save against your Mental SL or they take 2d10 poison damage and become poisoned for 1 minute (2d4 poison damage at the start of their turn)." },
      ] },
      { lvl: 8, features: [
        { name: "Memory", text: "Five charges of RAM can be used per long rest. Additionally, critically succeeding on a Mental saving roll or Mind-related skill check grants a charge of RAM (expires on your next long rest if unused)." },
        { name: "Mass Injection", action: ">>", text: "Expend a charge of RAM and attempt to inject every hostile target within 30ft. Physical save against your Mental SL or injected for 1 minute." },
      ] },
      { lvl: 10, features: [{ name: "Malfunction", action: ">>", text: "Expend three charges of RAM and select an injected target within 25ft. Mental save against you or they take 6d6 ion damage as your nanites unleash a powerful pulse, and begin malfunctioning for 1 minute (Inept with skill checks, saving rolls, and attack rolls)." }] },
      { lvl: 12, features: [
        { name: "Memory", text: "Six charges of RAM can be used per long rest." },
        { name: "Malfunction", text: "Deals 6d6 +Mind modifier ion damage." },
      ] },
    ],
  },
  {
    name: "Redwire", parentPath: "Specialist",
    blurb: "A specialist bound to advanced technology by an obsession with power — a redwire hacker who sacrifices their own health to recode the Grand Galaxy.",
    progression: [
      { lvl: 2, features: [{ name: "Rogue AI", action: ">>", text: "Roll a d6 + Body modifier; subtract the result from your current health and become mirrored for 1 minute. While mirrored, an AI copy of you appears whenever you make an attack roll — after dealing weapon damage to a target, make another attack roll against the same target as your AI counterpart. On a hit, 2d4 unknown damage." }] },
      { lvl: 4, features: [
        { name: "Rogue AI", text: "When a target is hit by your AI counterpart, they take 2d4 +Mind modifier unknown damage." },
        { name: "Reboot", action: "<", text: "Reaction to taking damage while mirrored: your AI counterpart takes half the incoming damage. After you take the rest, the mirrored condition ends early." },
      ] },
      { lvl: 6, features: [
        { name: "Rogue AI", text: "Costs one less action to use." },
        { name: "Obliteration", action: ">>", text: "Roll a d8 + Body modifier; subtract the result from your current health. Select a target within 30ft and attempt to destroy them with living code. Mental save against you or they take 3d10 +Mind modifier unknown damage." },
      ] },
      { lvl: 8, features: [
        { name: "Rogue AI", action: "<", text: "Can be used as a reaction to taking damage." },
        { name: "Obliteration", text: "After dealing damage, the target becomes obliterated for 1 minute (vulnerability score of 2 against unknown damage; AR reduced by half your Mind modifier)." },
      ] },
      { lvl: 10, features: [
        { name: "Rogue AI", text: "Deals 3d4 +Mind modifier unknown damage." },
        { name: "Conversion", action: ">>", text: "Roll a d10 + Body modifier; subtract the result from your current health. Select a creature within 30ft and attempt to rewrite their mind. Mental save against you or converted for 1 minute (treats allies as enemies and vice versa)." },
      ] },
      { lvl: 12, features: [
        { name: "Rogue AI", text: "Deals 3d6 +Mind modifier unknown damage." },
        { name: "Obliteration", text: "Deals 3d12 +Mind modifier unknown damage." },
      ] },
    ],
  },
  // ===== SPIRITUALIST =====
  {
    name: "Sorcerer", parentPath: "Spiritualist",
    blurb: "A Spiritualist more attuned to their soul than others, cursing enemies — usually at a cost.",
    progression: [
      { lvl: 2, features: [{ name: "Curse", action: ">", text: "Signature 1st level sorcery power. Select a creature within 25ft and attempt to hex them. Spiritual save against you or choose one: Damage (2d12 +Spirit modifier necrotic, you receive a point of Exhaustion) or Movement (entangled for 1 minute; while a creature is entangled, your movement is halved while facing them)." }] },
      { lvl: 4, features: [{ name: "Curse", text: "Cast with a 2nd level slot, choose from: Damage (3d12 +Spirit modifier necrotic, two points of Exhaustion), Movement (entangled, your movement unaffected), Turn (creature's next turn is skipped; until they act, your powers cost an extra action), or Charm (creature won't attack you next turn; until it attacks you, your attack rolls suffer a \u22124 penalty)." }] },
      { lvl: 6, features: [{ name: "Corruption", action: "<", text: "When you'd suffer the negative effects of a Curse, instead roll hit dice equal to the Curse's power level and add your Spirit score to the result, subtracting the total from your current health. Using this negates the negative effects of the last Curse used." }] },
      { lvl: 8, features: [{ name: "Curse", text: "Cast with a 3rd level slot, choose from: Damage (4d12 +Spirit modifier necrotic, three points of Exhaustion), Movement (entangled, your movement doubled while facing them), Turn (extra action for you before their skipped turn), Charm (attack rolls and damage rolls suffer a \u22122 penalty until they attack you), or Lifesteal (roll hit dice + target's Spirit modifier, double the result and add it to your current health)." }] },
      { lvl: 10, features: [{ name: "Curse", text: "When this power deals damage, receive two points of Exhaustion instead of three." }] },
      { lvl: 12, features: [{ name: "Curse", text: "When this power deals damage, receive one point of Exhaustion instead of two." }] },
    ],
  },
  {
    name: "Technomancer", parentPath: "Spiritualist",
    blurb: "A Spiritualist whose electric spark, crackling since a young age, has finally been brought under control.",
    progression: [
      { lvl: 2, features: [{ name: "Implantation", action: ">", text: "Signature 1st level technomancy power. Select a target within 30ft. Mental save against your Spiritual SL or they're implanted for 1 minute (vulnerability score of 4 against ion damage)." }] },
      { lvl: 4, features: [
        { name: "Implantation", action: "<", text: "Cast with a 2nd level slot: use as a reaction at any time to detonate the implant. Physical save against your Spiritual SL or the target takes 2d8 fire and 2d8 +Spirit modifier ion damage. Ends the implanted condition." },
        { name: "Lightning Strikes", action: ">>", text: "Signature 2nd level technomancy power. Fire electricity in a 10ft cone. Spiritual save against you or 3d8 +Spirit modifier ion damage. Exhaustive." },
      ] },
      { lvl: 6, features: [
        { name: "Implantation", text: "While implanted, a target also suffers a vulnerability score of 2 against plasma and sonic damage." },
        { name: "Lightning Strikes", text: "Against implanted targets, deals 3d10 +Spirit modifier ion damage." },
      ] },
      { lvl: 8, features: [
        { name: "Implantation", text: "Cast with a 3rd level slot: the vulnerability score against ion damage becomes 6." },
        { name: "Lightning Strikes", text: "Cast with a 3rd level slot: range increases by 5ft, and creatures take 4d8 +Spirit modifier ion damage after failing the save (4d10 +Spirit modifier against implanted targets)." },
        { name: "Summon Specter", action: ">", text: "Signature 3rd level technomancy power. Summon a GM-controlled specter in an unoccupied space within 20ft, prioritizing harming your enemies. Lasts 1 minute." },
      ] },
      { lvl: 10, features: [{ name: "Summon Sentinel", action: ">", text: "Signature 3rd level technomancy power. Summon a GM-controlled sentinel in an unoccupied space within 25ft, prioritizing harming your enemies. Lasts 1 minute." }] },
      { lvl: 12, features: [
        { name: "Implantation", text: "When implantation expires, it detonates automatically. Physical save against your Spiritual SL or 3d8 fire and 3d8 +Spirit modifier ion damage." },
        { name: "Lightning Strikes", text: "Deals 4d12 +Spirit modifier ion damage against implanted targets." },
      ] },
    ],
  },
];


const ADVANCEMENTS = [
  { name: "Additional Path", repeatable: false, text: "Claim the features of another path and one of its pathways. Doesn't affect hit dice or how you receive rewards on level-up. Can't be taken alongside Power Potential. Bioweapons, Mavericks, and Specialists also gain access to that path's power slots and power points (if it has any)." },
  { name: "Blade Mastery", repeatable: false, text: "Add your Adept dice to damage rolls made with Blades." },
  { name: "Blaster Mastery", repeatable: false, text: "Add your Agility modifier to damage rolls made with Blasters. Doesn't affect Flurry damage rolls." },
  { name: "Bow Mastery", repeatable: false, text: "Add your Adept dice to damage rolls made with Bows." },
  { name: "Clairvoyance Master", repeatable: false, text: "The effects of your clairvoyance powers last twice as long. Mentalists and Spiritualists can't take this Advancement." },
  { name: "Ordination Mastery", repeatable: false, text: "Add your Adept dice to damage rolls made with ordination powers (only one damage roll if a power makes several). Mentalists and Spiritualists can't take this Advancement." },
  { name: "Polearm Mastery", repeatable: false, text: "Add your Adept dice to damage rolls made with Polearms." },
  { name: "Power Potential", repeatable: false, text: "Receive a power point every other level, retroactively. Not available to Bioweapons, Mavericks, Specialists, or characters with Additional Path." },
  { name: "Save Bound", repeatable: false, text: "Become Adept with a saving roll of your choice." },
  { name: "Score Bound", repeatable: true, text: "Raise one attribute score by 1 (max 12)." },
  { name: "Skill Bound", repeatable: true, text: "Become Adept with a skill check of choice, or turn an Inept skill into a standard roll." },
  { name: "Sorcery Master", repeatable: false, text: "Add your Adept dice to damage rolls made with sorcery powers (only one damage roll if a power makes several). Mentalists and Spiritualists can't take this Advancement." },
  { name: "Technomancy Mastery", repeatable: false, text: "The effects of your technomancy powers (and summoned constructs) last twice as long. Mentalists and Spiritualists can't take this Advancement." },
  { name: "Unarmored Expertise", repeatable: false, text: "When no armor is equipped, your AR is increased by half your highest attribute score." },
];

/* -------------------------------- MUTATIONS -------------------------------- */
/* Bioweapon-exclusive; usable only while enraged. */
const MUTATIONS = [
  { name: "Acidic Shot", action: ">>", cost: 2, text: "Attack roll (+Adept dice) +Agility vs target within 25ft: 4d6 acid damage, target makes a Physical save or is pinned (Athletics DR 22 to break free; failing deals 2d8 acid and keeps them pinned)." },
  { name: "Containment", action: "", cost: 2, text: "Add half your unspent mutation points to each Blade damage roll." },
  { name: "Devour", action: "<", cost: 1, text: "Reaction to taking damage: grow tiny mouths. Next damage you deal to a creature within 5ft heals you for half the damage dealt." },
  { name: "Grow Claws", action: ">", cost: 2, text: "Two attack rolls (+Adept dice) +Body vs a creature within 5ft; each hit deals 2d6 +Body slashing. A critical hit causes bleeding (3 HP lost per action for 1 minute)." },
  { name: "Hardened Skin", action: "", cost: 3, text: "All damage you take is reduced by 5 points." },
  { name: "Open Heart", action: "", cost: 3, text: "All healing you receive is doubled." },
  { name: "Strand", action: "<", cost: 1, text: "Reaction when a target within 25ft moves: Physical save or they're pulled within 5ft and lose remaining movement." },
  { name: "Tendrils Unleashed", action: ">>", cost: 3, text: "Three targets within 15ft make a Physical save or take 5d10 bludgeoning and become entangled for 1 minute (fire/acid can destroy the tendrils early)." },
  { name: "Disfiguration", action: ">>", cost: 2, text: "Disfigure yourself for 1 minute. Creatures starting their turn within 15ft make a Spiritual save against your Physical SL or become fearful (roll Spiritual saves twice, use lower)." },
  { name: "Venomous Aura", action: "", cost: 3, text: "Creatures starting their turn within 5ft make a Physical save or take 4d4 +Body poison damage and become poisoned (3d4 poison at the start of their turn) for 1 minute." },
];

/* ---------------------------------- POWERS ---------------------------------- */
/* discipline: Clairvoyance & Ordination = Mentalism; Sorcery & Technomancy = Spiritualism */
const POWERS = [
  // ===== CLAIRVOYANCE =====
  { name: "Precognition", discipline: "Clairvoyance", level: 1, action: ">>", pp: 1, range: "Self", text: "Your mind opens to reality's probabilities for 1 minute: add half your Mind modifier to non-Mind skill checks.", heighten: ["2nd slot: add your whole Mind modifier instead of half.", "3rd slot: add your Mind modifier to your next Physical or Spiritual saving roll."] },
  { name: "Beast Sense", discipline: "Clairvoyance", level: 1, action: ">", pp: 1, range: "Nearby (outside)", text: "See through a nearby beast's eyes for 1 minute. Afterward, Perception checks get +1 for an hour.", heighten: ["Level 4+: see through two beasts at once; the Perception bonus becomes +2."] },
  { name: "Psychic Brand", discipline: "Clairvoyance", level: 1, action: ">", pp: 2, range: "Touch", text: "Brand a Blade or Polearm with psychic energy for 1 minute — it deals psychic damage instead of its normal type." },
  { name: "Psychic Spike", discipline: "Clairvoyance", level: 1, action: ">", pp: 2, range: "25ft", text: "Attack roll (+Adept dice) +Mind vs a creature within 25ft. On a hit: 2d8 +Mind modifier psychic damage.", heighten: ["2nd slot: 3d8 +Mind modifier.", "3rd slot: 4d8 +Mind modifier."] },
  { name: "Finder's Memory", discipline: "Clairvoyance", level: 1, action: ">", pp: 1, range: "5ft", text: "Imbue a small item with a piece of your mind — you always know its location until you use this power again.", heighten: ["2nd slot: spend an action to summon the item to you."] },
  { name: "Foresight", discipline: "Clairvoyance", level: 1, action: ">", pp: 2, range: "Self", text: "Roll a d20; the result (\"Foresight dice\") can replace a later attack roll, skill check, or saving roll. Expires before your next long rest." },
  { name: "Slumber", discipline: "Clairvoyance", level: 1, action: ">", pp: 1, range: "15ft", text: "An unsuspecting creature within 15ft makes a Mental save or falls asleep. Sneaking past them gets +2 Stealth; on a success save, they notice you." },
  { name: "Telepathy", discipline: "Clairvoyance", level: 1, action: ">", pp: 1, range: "Allies", text: "Establish a telepathic bond with your allies until your next long rest." },
  { name: "Disarm", discipline: "Clairvoyance", level: 2, action: ">", pp: 1, range: "25ft", text: "A creature within 25ft makes a Mental save or drops their weapon; reclaiming it costs an action at the start of their next turn.", heighten: ["Level 6+: the dropped item is flung 15ft, requiring movement and an action to reclaim."] },
  { name: "Engulf", discipline: "Clairvoyance", level: 2, action: ">", pp: 2, range: "30ft", text: "Exhaustive. A creature within 30ft makes a Mental save or the illusion of flames becomes real: 3d10 fire damage.", heighten: ["3rd slot: 5d10 fire damage."] },
  { name: "False Mind", discipline: "Clairvoyance", level: 2, action: ">", pp: 3, range: "20ft", text: "A creature within 20ft makes a Mental save or believes a fabricated temporary memory.", heighten: ["Level 8+: the memory becomes permanent."] },
  { name: "Psychic Barrier", discipline: "Clairvoyance", level: 2, action: "<", pp: 2, range: "Self", text: "Reaction to taking damage: the next attacker must make a Mental save or take 3d8 psychic damage. Expires on use.", heighten: ["3rd slot: 3d8 +Mind modifier psychic damage."] },
  { name: "Remembrance", discipline: "Clairvoyance", level: 2, action: ">>", pp: 2, range: "25ft", text: "Exhaustive. A creature within 25ft makes a Mental save or takes 3d10 psychic damage and becomes distracted for 1 minute (rolls Mental saves twice, uses lower).", heighten: ["3rd slot: 4d10 psychic damage."] },
  { name: "Thought Burst", discipline: "Clairvoyance", level: 2, action: ">", pp: 3, range: "30ft", text: "A creature within 30ft makes a Mental save or takes 3d6 +Mind psychic damage and gains a vulnerability score of 2 to psychic damage for 1 minute.", heighten: ["3rd slot: 3d8 +Mind modifier damage; vulnerability score becomes 4."] },
  { name: "Dominate", discipline: "Clairvoyance", level: 3, action: ">>", pp: 3, range: "30ft", text: "A creature within 30ft makes a Mental save or you take control of them at the start of their next turn, gaining access to their powers/abilities/equipment for one action before your mind returns.", heighten: ["Level 10+: use both of the controlled creature's actions.", "Level 12: the creature takes 3d10 psychic damage when you leave their body."] },
  { name: "Nightmarish Form", discipline: "Clairvoyance", level: 3, action: "<", pp: 3, range: "Self", text: "When attacked, turn into the attacker's worst nightmare: Mental save or 4d8 psychic damage now and 2d8 more at the start of their next turn." },
  { name: "Psychometry", discipline: "Clairvoyance", level: 3, action: ">", pp: 1, range: "15ft", text: "Attach your mind to an object for 1 hour, seeing/hearing from its perspective and accessing its memory. Only one active at a time.", heighten: ["Level 12: the link lasts as long as you wish."] },
  { name: "Read Thoughts", discipline: "Clairvoyance", level: 3, action: ">", pp: 2, range: "20ft", text: "Outside combat: target within 20ft makes a Physical save against your Spiritual SL or their thoughts are revealed. In combat: target makes a Mental save or their next two actions are revealed to you." },

  // ===== ORDINATION (requires being bonded with a Vessel) =====
  { name: "Beyond Barrier", discipline: "Ordination", level: 1, action: "<", pp: 2, range: "Self", text: "Reaction to taking damage: the attacker makes a Physical save against your Mental SL or takes 2d8 radiant damage. Expires on use.", heighten: ["2nd slot: 3d8 radiant damage.", "3rd slot: 3d8 +Mind modifier radiant damage."] },
  { name: "Beyonder's Touch", discipline: "Ordination", level: 1, action: ">", pp: 1, range: "5ft", text: "Touch a friendly creature within 5ft to grant 2d4 +Mind modifier healing.", heighten: ["2nd slot: touch a hostile creature instead — Spiritual save or 3d10 radiant damage."] },
  { name: "Glow", discipline: "Ordination", level: 1, action: ">", pp: 1, range: "15ft radius", text: "Surround yourself in Beyond-light for an hour, illuminating a 15ft radius (no effect on magically-created darkness)." },
  { name: "Energy Cannon", discipline: "Ordination", level: 1, action: ">>", pp: 2, range: "30ft", text: "Exhaustive. Attack roll (+Adept dice) +Mind vs a target within 30ft: 3d10 plasma, ion, or sonic damage.", heighten: ["2nd slot: 4d10 +Mind modifier damage."] },
  { name: "Resonance", discipline: "Ordination", level: 1, action: "<", pp: 2, range: "Self", text: "Exhaustive. Reaction while below half health: roll your Vessel's hit dice (no modifiers) and regain that much health.", heighten: ["2nd slot: roll twice, use the higher.", "3rd slot: add your Vessel's Body modifier to the roll."] },
  { name: "Tractor Beam", discipline: "Ordination", level: 1, action: "<", pp: 1, range: "20ft", text: "Reaction to a target moving within 20ft: Physical save against your Mental SL or the target is immobilized for 1 minute." },
  { name: "Vessel's Guide", discipline: "Ordination", level: 1, action: ">", pp: 3, range: "Self", text: "For an hour, add half your Vessel's applicable modifier (instead of your own) to skill checks.", heighten: ["2nd slot: add the whole modifier instead of half.", "3rd slot: add your own modifier alongside your Vessel's."] },
  { name: "Vessel Sense", discipline: "Ordination", level: 1, action: ">", pp: 1, range: "Vessel link", text: "Check your bonded Vessel's current health, shield, and any active conditions." },
  { name: "Beyond Blast", discipline: "Ordination", level: 2, action: ">>", pp: 2, range: "25ft, 10ft radius", text: "Exhaustive. A bright light lasts 1 minute; creatures starting their turn in it make a Spiritual save against your Mental SL or take 4d8 radiant damage.", heighten: ["3rd slot: 5d8 +Spirit modifier damage."] },
  { name: "Gravity Burst", discipline: "Ordination", level: 2, action: ">>", pp: 2, range: "15ft", text: "Up to three targets within 15ft make a Physical save or are lifted and slammed down for 3d10 +Body modifier bludgeoning damage." },
  { name: "Harmony", discipline: "Ordination", level: 2, action: ">", pp: 1, range: "25ft", text: "Attack roll (+Adept dice) +Agility vs a creature within 25ft: 3d6 +Mind modifier sonic damage.", heighten: ["Level 8+: 3d8 +Mind modifier.", "Level 10+: 3d10 +Mind modifier."] },
  { name: "Spiral", discipline: "Ordination", level: 2, action: ">", pp: 1, range: "25ft", text: "Attack roll (+Adept dice) +Agility vs a creature within 25ft: 3d8 +Mind modifier radiant damage." },
  { name: "Command Vessel", discipline: "Ordination", level: 3, action: ">", pp: 3, range: "Sight", text: "The target Vessel's ordinator makes a Mental save against you, or you control the Vessel's first action next turn." },
  { name: "Emanation", discipline: "Ordination", level: 3, action: "<", pp: 2, range: "Self", text: "Reaction to taking damage: shield yourself for 1 minute — anyone who damages you makes a Physical save against your Mental SL or takes 6d6 radiant damage.", heighten: ["Level 10+: can be cast as an action at the end of your turn.", "3rd slot: also targets a second creature with the same attack.", "Level 12: deals 6d6 +Spirit modifier radiant damage."] },
  { name: "Vessel Blade", discipline: "Ordination", level: 3, action: ">", pp: 3, range: "Self", text: "Your next damage roll adds half your Vessel's applicable modifier.", heighten: ["3rd slot: add the whole modifier instead of half."] },
  { name: "Excision", discipline: "Ordination", level: 3, action: ">>", pp: 3, range: "15ft (self included)", text: "Exhaustive. All creatures within 15ft (including you) make a Physical save against your Mental SL or take 8d8 radiant damage.", heighten: ["3rd slot: 8d8 +Mind modifier radiant damage."] },
  { name: "Vessel Save", discipline: "Ordination", level: 3, action: ">", pp: 2, range: "Self", text: "Your next saving roll adds half your Vessel's applicable modifier.", heighten: ["3rd slot: add the whole modifier instead of half."] },
  { name: "Renewal", discipline: "Ordination", level: 3, action: "", pp: 3, range: "Self", text: "If you hit 0 HP and fail all Mercy rolls, the Beyond fully heals you and replenishes all power slots instead of letting you die — unless your 3rd level slots were already spent." },

  // ===== SORCERY =====
  { name: "Below Blast", discipline: "Sorcery", level: 1, action: ">", pp: 2, range: "25ft", text: "Attack roll (+Adept dice) +Spirit vs a target within 25ft: 2d8 +Spirit modifier force damage.", heighten: ["2nd slot: also target an additional creature with another attack roll.", "3rd slot: 4d8 +Spirit modifier damage."] },
  { name: "Below Fire", discipline: "Sorcery", level: 1, action: ">>", pp: 2, range: "25ft, 10ft radius", text: "Exhaustive. Flames cover a 10ft radius; creatures inside make a Physical save against your Spiritual SL or take 2d12 fire damage. Extinguishes once it deals damage." },
  { name: "Blink", discipline: "Sorcery", level: 1, action: "<", pp: 1, range: "20ft", text: "Reaction to taking damage: teleport to an unoccupied space within 20ft.", heighten: ["2nd slot: creatures within 10ft of your old space make a Spiritual save or take 2d6 +Spirit modifier force damage.", "3rd slot: 4d6 +Spirit modifier damage."] },
  { name: "Blackspace", discipline: "Sorcery", level: 1, action: ">>", pp: 2, range: "25ft, 10ft radius", text: "A dark, cold cloud lasts 1 minute (ends early if you cast another power). Creatures starting their turn inside make a Spiritual save or take 2d8 frost damage and have movement halved for 1 minute. Creatures inside are concealed and partially blinded (-5 to attack rolls).", heighten: ["2nd slot: 3d8 +Spirit modifier frost damage.", "3rd slot: costs one less action and deals 4d10 +Spirit modifier frost damage."] },
  { name: "Disturb Dead", discipline: "Sorcery", level: 1, action: ">", pp: 1, range: "5ft", text: "Momentarily resurrect the spirit of a dead creature within 5ft to talk to; it fades after 1 minute and can't be disturbed again.", heighten: ["2nd slot: gain a resistance score of 2 against necrotic damage for an hour, and roll your next Spiritual save twice, using the higher."] },
  { name: "Form Frost", discipline: "Sorcery", level: 1, action: ">", pp: 2, range: "30ft", text: "Exhaustive. A creature within 30ft makes a Spiritual save or takes 2d8 frost damage and gains a vulnerability score of 2 to frost for 1 minute.", heighten: ["Level 4+: 2d8 +Spirit modifier damage.", "Level 8+: the vulnerability score becomes 4."] },
  { name: "Heal", discipline: "Sorcery", level: 1, action: ">", pp: 1, range: "25ft", text: "A creature within 25ft receives 2d6 healing.", heighten: ["2nd slot: 3d6 +Mind modifier healing.", "3rd slot: 4d6 +Mind modifier healing."] },
  { name: "Connect", discipline: "Sorcery", level: 2, action: ">>", pp: 2, range: "Recently damaged", text: "Two creatures you've damaged in the last minute make a Spiritual save or become tethered for 1 minute — damage to one is halved and applied to the other too.", heighten: ["3rd slot: add an additional creature to the connection."] },
  { name: "Create Nightmare", discipline: "Sorcery", level: 2, action: ">>", pp: 3, range: "30ft", text: "An unmovable nightmarish image appears for 1 minute. Creatures starting their turn within 15ft make a Spiritual save or become fearful (roll Spiritual saves twice, use lower) for 1 minute.", heighten: ["3rd slot: fearful creatures take 3d10 necrotic damage each time they fail a Spiritual save."] },
  { name: "Sickness", discipline: "Sorcery", level: 2, action: ">", pp: 1, range: "20ft", text: "A creature within 20ft makes a Spiritual save or takes 2d4 poison damage and becomes sickened for 1 minute (healing they receive is halved).", heighten: ["Level 6+: sickened creature takes another 2d4 poison damage at the start of their next turn."] },
  { name: "Regenerate", discipline: "Sorcery", level: 2, action: ">", pp: 2, range: "20ft", text: "A creature within 20ft that takes damage rolls their hit dice at the start of their next turn and adds the result to their current health.", heighten: ["3rd slot: roll the hit dice three times, use the highest."] },
  { name: "Sever", discipline: "Sorcery", level: 2, action: ">", pp: 3, range: "20ft", text: "A creature within 20ft makes a Physical save against your Spiritual SL or takes 4d4 +Spirit modifier slashing damage and begins bleeding (2 HP per action for up to an hour, until healed).", heighten: ["3rd slot: bleeding worsens to 4 HP per action.", "Level 10+: base damage becomes 4d6 +Spirit modifier."] },
  { name: "Spectral Blade", discipline: "Sorcery", level: 2, action: ">", pp: 1, range: "Self", text: "Summon a spectral shortsword for 1 minute (uses Spirit modifier for attack rolls). On a hit: 2d8 +Spirit modifier slashing damage.", heighten: ["3rd slot: summons a spectral longsword instead — 3d10 +Spirit modifier slashing damage on a hit."] },
  { name: "Spectral Bow", discipline: "Sorcery", level: 2, action: ">", pp: 2, range: "Self", text: "Summon a spectral longbow for 1 minute (uses Spirit modifier for attack rolls). On a hit: 2d8 +Spirit modifier piercing damage." },
  { name: "Cleanse", discipline: "Sorcery", level: 3, action: ">>", pp: 3, range: "25ft", text: "Exhaustive. A friendly creature within 25ft has all negative effects currently on them removed.", heighten: ["Level 12: no longer exhaustive, and costs one less action."] },
  { name: "Elemental Hold", discipline: "Sorcery", level: 3, action: ">>", pp: 3, range: "30ft", text: "A target within 30ft is trapped in an orb of fire, frost, or force and can't act. Each turn they attempt a Spiritual save against you to break free; failing deals 5d8 +Spirit modifier damage of the chosen type. Ends when they break out or die.", heighten: ["Level 12: deals 6d8 +Spirit modifier damage instead."] },
  { name: "Elemental Weave", discipline: "Sorcery", level: 3, action: ">>", pp: 2, range: "35ft, 15ft radius", text: "Exhaustive. Sharp elemental strands last 1 minute; creatures starting their turn inside make a Spiritual save or take 5d10 +Spirit modifier fire, frost, or force damage.", heighten: ["Level 10+: 5d12 +Spirit modifier damage.", "Level 12: no longer exhaustive."] },
  { name: "Evolve", discipline: "Sorcery", level: 3, action: ">>", pp: 3, range: "30ft", text: "A creature within 30ft makes a Physical save against your Spiritual SL or is forced through a painful transformation over three turns — 2d10 acid, then 2d10 slashing, then 2d10 necrotic damage — auto-failing all rolls and unable to move throughout, before all physical changes revert." },

  // ===== TECHNOMANCY =====
  { name: "Arcpoint", discipline: "Technomancy", level: 1, action: ">>", pp: 2, range: "20ft, 10ft radius", text: "An ion-bolt is thrown down; creatures within 10ft make a Physical save against your Spiritual SL or take 2d4 +Spirit modifier ion damage. After 1 minute it expires, dealing the same damage again to anyone within 10ft.", heighten: ["Level 3+: damage becomes 2d6 +Spirit modifier (both instances)."] },
  { name: "Create Construct", discipline: "Technomancy", level: 1, action: ">>", pp: 2, range: "20ft", text: "Summon a GM-controlled drone that prioritizes healing allies, lasting 1 minute.", heighten: ["2nd slot: summons a battlebot instead.", "3rd slot: summons a warbot instead."] },
  { name: "Create Cover", discipline: "Technomancy", level: 1, action: ">", pp: 1, range: "25ft", text: "Summon technological debris that grants half-concealment; lasts until combat ends." },
  { name: "Repair", discipline: "Technomancy", level: 1, action: ">", pp: 1, range: "5ft", text: "A small broken object within 5ft repairs itself, provided all its parts are present." },
  { name: "Sense Constructs", discipline: "Technomancy", level: 1, action: ">>", pp: 1, range: "50ft", text: "Pinpoint the exact location of any constructs within 50ft." },
  { name: "Soundwave", discipline: "Technomancy", level: 1, action: ">>", pp: 2, range: "10ft cone", text: "Creatures in a 10ft cone make a Physical save against your Spiritual SL or take 2d10 sonic damage.", heighten: ["2nd slot: 2d10 +Spirit modifier damage.", "3rd slot: 4d10 +Spirit modifier damage."] },
  { name: "Spark Surge", discipline: "Technomancy", level: 1, action: ">>", pp: 2, range: "20ft", text: "Exhaustive. Attack roll (+Adept dice) +Spirit vs a creature within 20ft: 2d10 lightning damage; a creature within 5ft of the target makes a Spiritual save or takes half that damage too." },
  { name: "Imbue Mind", discipline: "Technomancy", level: 1, action: ">", pp: 2, range: "25ft", text: "A construct within 25ft makes a Spiritual save or becomes mind-imbued for 1 minute — targetable by clairvoyance powers as if it were a creature, and no longer immune to psychic damage.", heighten: ["2nd slot: deals 3d10 lightning damage, and a target within 5ft of the effect auto-fails its Spiritual save."] },
  { name: "Imbue Spirit", discipline: "Technomancy", level: 1, action: ">", pp: 2, range: "25ft", text: "A construct within 25ft makes a Spiritual save or becomes spirit-imbued for 1 minute — targetable by sorcery powers as if it were a creature, and no longer immune to radiant/necrotic damage.", heighten: ["3rd slot: deals 4d10 ion damage."] },
  { name: "Twitch", discipline: "Technomancy", level: 1, action: "<", pp: 1, range: "Self", text: "Reaction to taking damage: for 1 minute, add half your Spirit modifier to your AR (ends early if you take damage while active).", heighten: ["2nd slot: add your whole Spirit modifier instead of half.", "3rd slot: add your Spirit score instead of your modifier."] },
  { name: "Malware", discipline: "Technomancy", level: 2, action: ">>", pp: 3, range: "25ft", text: "A construct within 25ft makes a Physical save against your Spiritual SL or takes 3d10 ion damage and auto-fails its next roll." },
  { name: "Ion Cloud", discipline: "Technomancy", level: 2, action: ">>", pp: 3, range: "25ft, 10ft radius", text: "An electric cloud lasts 1 minute (ends early if you cast another power). Constructs starting their turn inside make a Physical save against your Spiritual SL or take 3d8 ion damage and have movement halved for 1 minute.", heighten: ["3rd slot: costs one less action and deals 4d10 +Spirit modifier frost damage."] },
  { name: "Stun", discipline: "Technomancy", level: 2, action: ">", pp: 1, range: "25ft", text: "A construct within 25ft makes a Mental save against your Spiritual SL or loses an action at the start of its next turn." },
  { name: "Laser Vision", discipline: "Technomancy", level: 2, action: ">", pp: 2, range: "15ft", text: "Exhaustive. Attack roll (+Adept dice) +Spirit vs two targets within 15ft: each hit deals 4d6 +Spirit modifier plasma damage." },
  { name: "Destroy", discipline: "Technomancy", level: 3, action: ">>", pp: 3, range: "Recently damaged", text: "A construct you've damaged in the last minute makes a Mental save against your Spiritual SL or takes 5d10 +Spirit modifier ion damage.", heighten: ["Level 12: 5d12 +Spirit modifier damage."] },
  { name: "Maelstrom", discipline: "Technomancy", level: 3, action: "<", pp: 2, range: "15ft", text: "Reaction to taking damage: a destructive shield lasts 1 minute. Anyone within 15ft who fails a skill check, saving roll, or attack roll takes 5d6 +Spirit modifier ion damage.", heighten: ["Level 10+: 5d8 +Spirit modifier damage."] },
  { name: "Hijack", discipline: "Technomancy", level: 3, action: ">>", pp: 3, range: "30ft", text: "A construct within 30ft makes a Mental save against your Spiritual SL or you control it at the start of its next turn, gaining its abilities/equipment for one action before your mind returns.", heighten: ["Level 10+: use both of the construct's actions."] },
  { name: "Signal Jam", discipline: "Technomancy", level: 3, action: ">", pp: 2, range: "5ft radius", text: "Constructs starting their turn within 5ft of you can't move or act, until you take plasma, ion, or sonic damage." },
];

/* --------------------------------- WEAPONS --------------------------------- */
/* tier: "standard" (core rulebook) or "superior" (the Galactic Guide, "II" gear).
   Superior weapons can take Modifications; standard ones cannot. */
const WEAPONS = [
  // ===== STANDARD BLADES =====
  { name: "Dagger", category: "Blades", tier: "standard", cost: 150, action: ">", atkAttr: "Agility", range: "5ft", dice: "1d4", dmgMod: "Body", dmgType: "slashing", bulk: 2, special: "Flurry — dual-wielded, two attacks at 5ft; each hit deals 1d4 slashing (no modifier)." },
  { name: "Shortsword", category: "Blades", tier: "standard", cost: 200, action: ">", atkAttr: "Body", range: "5ft", dice: "1d6", dmgMod: "Body", dmgType: "slashing", bulk: 2, special: "Flurry — dual-wielded, two attacks at 5ft; each hit deals 1d6 slashing (no modifier)." },
  { name: "Longsword", category: "Blades", tier: "standard", cost: 250, action: ">", atkAttr: "Body", range: "5ft", dice: "1d8", dmgMod: "Body", dmgType: "slashing", bulk: 4, special: "Versatile — two-handed attack deals 1d10 +Body slashing instead." },
  { name: "Greatsword", category: "Blades", tier: "standard", cost: 300, action: ">", atkAttr: "Body", range: "5ft", dice: "1d12", dmgMod: "Body", dmgType: "slashing", bulk: 6 },
  // ===== STANDARD BLASTERS =====
  { name: "Pulse Pistol", category: "Blasters", tier: "standard", cost: 220, action: ">", atkAttr: "Agility", range: "35ft", dice: "2d6", dmgMod: null, dmgType: "plasma", bulk: 2, special: "Flurry — dual-wielded pistols, two attacks at 25ft; each hit deals 2d4 plasma." },
  { name: "Charge Pistol", category: "Blasters", tier: "standard", cost: 420, action: ">", atkAttr: "Agility", range: "35ft", dice: "2d6", dmgMod: null, dmgType: "ion", bulk: 2, special: "Flurry — dual-wielded pistols, two attacks at 25ft; each hit deals 2d4 ion." },
  { name: "Echo Pistol", category: "Blasters", tier: "standard", cost: 435, action: ">", atkAttr: "Agility", range: "35ft", dice: "2d6", dmgMod: null, dmgType: "sonic", bulk: 2, special: "Flurry — dual-wielded pistols, two attacks at 25ft; each hit deals 2d6 sonic." },
  { name: "Pulse Caster", category: "Blasters", tier: "standard", cost: 250, action: ">", atkAttr: "Agility", range: "20ft", dice: "2d6", dmgMod: null, dmgType: "plasma", bulk: 3, special: "Rapid Fire — 2 actions, 10ft cone, Physical save vs you or 2d6 plasma." },
  { name: "Charge Caster", category: "Blasters", tier: "standard", cost: 250, action: ">", atkAttr: "Agility", range: "20ft", dice: "2d6", dmgMod: null, dmgType: "plasma", bulk: 3, special: "Rapid Fire — 2 actions, 10ft cone, Physical save vs you or 2d6 plasma." },
  { name: "Pulse Repeater", category: "Blasters", tier: "standard", cost: 280, action: ">", atkAttr: "Agility", range: "45ft", dice: "2d8", dmgMod: null, dmgType: "plasma", bulk: 4 },
  { name: "Charge Repeater", category: "Blasters", tier: "standard", cost: 480, action: ">", atkAttr: "Agility", range: "45ft", dice: "2d8", dmgMod: null, dmgType: "ion", bulk: 4 },
  { name: "Echo Repeater", category: "Blasters", tier: "standard", cost: 480, action: ">", atkAttr: "Agility", range: "45ft", dice: "2d8", dmgMod: null, dmgType: "sonic", bulk: 4 },
  { name: "Pulse Shotgun", category: "Blasters", tier: "standard", cost: 280, action: ">", atkAttr: "Agility", range: "10ft", dice: "2d10", dmgMod: null, dmgType: "plasma", bulk: 5 },
  { name: "Charge Shotgun", category: "Blasters", tier: "standard", cost: 580, action: ">", atkAttr: "Agility", range: "10ft", dice: "2d10", dmgMod: null, dmgType: "ion", bulk: 5 },
  { name: "Echo Shotgun", category: "Blasters", tier: "standard", cost: 580, action: ">", atkAttr: "Agility", range: "10ft", dice: "2d10", dmgMod: null, dmgType: "sonic", bulk: 5 },
  { name: "Pulse Carbine", category: "Blasters", tier: "standard", cost: 300, action: ">", atkAttr: "Agility", range: "40ft", dice: "2d8", dmgMod: null, dmgType: "plasma", bulk: 3, special: "Rapid Fire — 2 actions, 20ft cone, Physical save vs you or 2d8 plasma." },
  { name: "Charge Carbine", category: "Blasters", tier: "standard", cost: 500, action: ">", atkAttr: "Agility", range: "40ft", dice: "2d8", dmgMod: null, dmgType: "ion", bulk: 3, special: "Rapid Fire — 2 actions, 20ft cone, Physical save vs you or 2d8 ion." },
  { name: "Echo Carbine", category: "Blasters", tier: "standard", cost: 500, action: ">", atkAttr: "Agility", range: "40ft", dice: "2d8", dmgMod: null, dmgType: "sonic", bulk: 3, special: "Rapid Fire — 2 actions, 20ft cone, Physical save vs you or 2d8 sonic." },
  { name: "Pulse Cannon", category: "Blasters", tier: "standard", cost: 280, action: ">", atkAttr: "Agility", range: "45ft", dice: "2d8", dmgMod: null, dmgType: "plasma", bulk: 4, est: true },
  { name: "Charge Cannon", category: "Blasters", tier: "standard", cost: 480, action: ">", atkAttr: "Agility", range: "45ft", dice: "2d8", dmgMod: null, dmgType: "ion", bulk: 4, est: true },
  { name: "Pulse Rifle", category: "Blasters", tier: "standard", cost: 350, action: ">>", atkAttr: "Agility", range: "75ft (unusable within 15ft)", dice: "2d12", dmgMod: null, dmgType: "plasma", bulk: 6 },
  { name: "Charge Rifle", category: "Blasters", tier: "standard", cost: 650, action: ">>", atkAttr: "Agility", range: "75ft (unusable within 15ft)", dice: "2d12", dmgMod: null, dmgType: "ion", bulk: 6 },
  { name: "Echo Rifle", category: "Blasters", tier: "standard", cost: 650, action: ">>", atkAttr: "Agility", range: "75ft (unusable within 15ft)", dice: "2d12", dmgMod: null, dmgType: "sonic", bulk: 6 },
  // ===== STANDARD BOWS =====
  { name: "Handbow", category: "Bows", tier: "standard", cost: 90, action: ">", atkAttr: "Agility", range: "20ft", dice: "1d4", dmgMod: "Agility", dmgType: "piercing", bulk: 2, est: true, special: "Flurry — dual-wielded, two attacks at 20ft; each hit deals 1d4 piercing (no modifier)." },
  { name: "Shortbow", category: "Bows", tier: "standard", cost: 120, action: ">", atkAttr: "Agility", range: "35ft", dice: "1d6", dmgMod: "Agility", dmgType: "piercing", bulk: 3 },
  { name: "Longbow", category: "Bows", tier: "standard", cost: 150, action: ">", atkAttr: "Agility", range: "45ft", dice: "1d8", dmgMod: "Agility", dmgType: "piercing", bulk: 4 },
  { name: "Crossbow", category: "Bows", tier: "standard", cost: 250, action: ">>", atkAttr: "Agility", range: "50ft", dice: "1d10", dmgMod: "Agility", dmgType: "piercing", bulk: 4, est: true },
  // ===== STANDARD POLEARMS =====
  { name: "Shortstaff", category: "Polearms", tier: "standard", cost: 50, action: ">", atkAttr: "Body", range: "5ft", dice: "1d6", dmgMod: "Body", dmgType: "bludgeoning", bulk: 2, special: "Flurry — dual-wielded, two attacks at 5ft; each hit deals 1d6 bludgeoning (no modifier)." },
  { name: "Longstaff", category: "Polearms", tier: "standard", cost: 80, action: ">", atkAttr: "Body", range: "10ft", dice: "1d8", dmgMod: "Body", dmgType: "bludgeoning", bulk: 3, est: true },
  { name: "Spear", category: "Polearms", tier: "standard", cost: 180, action: ">", atkAttr: "Agility", range: "10ft", dice: "1d10", dmgMod: "Agility", dmgType: "piercing", bulk: 3 },
  { name: "Glaive", category: "Polearms", tier: "standard", cost: 250, action: ">", atkAttr: "Body", range: "10ft", dice: "1d10", dmgMod: "Body", dmgType: "slashing", bulk: 6 },
  // ===== UNARMED =====
  { name: "Unarmed Strike", category: "Unarmed", tier: "standard", cost: 0, action: ">", atkAttr: "Body", range: "5ft", dice: "1d4", dmgMod: "Body", dmgType: "bludgeoning", bulk: 0 },

  // ===== SUPERIOR BLADES (Galactic Guide) =====
  { name: "Dagger II", category: "Blades", tier: "superior", cost: 150, action: ">", atkAttr: "Agility", range: "5ft", dice: "2d4", dmgMod: "Body", dmgType: "slashing", bulk: 2, special: "Flurry — dual-wielded, two attacks at 5ft; each hit deals 2d4 slashing (no modifier)." },
  { name: "Shortsword II", category: "Blades", tier: "superior", cost: 400, action: ">", atkAttr: "Body", range: "5ft", dice: "2d6", dmgMod: "Body", dmgType: "slashing", bulk: 2, special: "Flurry — dual-wielded, two attacks at 5ft; each hit deals 2d6 slashing (no modifier)." },
  { name: "Longsword II", category: "Blades", tier: "superior", cost: 450, action: ">", atkAttr: "Body", range: "5ft", dice: "2d8", dmgMod: "Body", dmgType: "slashing", bulk: 4, special: "Versatile — two-handed attack deals 2d10 +Body slashing instead." },
  { name: "Greatsword II", category: "Blades", tier: "superior", cost: 500, action: ">", atkAttr: "Body", range: "5ft", dice: "2d12", dmgMod: "Body", dmgType: "slashing", bulk: 6 },
  // ===== SUPERIOR BLASTERS =====
  { name: "Pulse Pistol II", category: "Blasters", tier: "superior", cost: 520, action: ">", atkAttr: "Agility", range: "40ft", dice: "3d6", dmgMod: null, dmgType: "plasma", bulk: 2, special: "Flurry — dual-wielded pistols, two attacks at 25ft; each hit deals 3d4 plasma." },
  { name: "Charge Pistol II", category: "Blasters", tier: "superior", cost: 620, action: ">", atkAttr: "Agility", range: "35ft", dice: "3d6", dmgMod: null, dmgType: "ion", bulk: 2, special: "Flurry — dual-wielded pistols, two attacks at 25ft; each hit deals 3d4 ion." },
  { name: "Echo Pistol II", category: "Blasters", tier: "superior", cost: 635, action: ">", atkAttr: "Agility", range: "35ft", dice: "3d6", dmgMod: null, dmgType: "sonic", bulk: 2, special: "Flurry — dual-wielded pistols, two attacks at 25ft; each hit deals 3d4 sonic." },
  { name: "Pulse Caster II", category: "Blasters", tier: "superior", cost: 550, action: ">", atkAttr: "Agility", range: "20ft", dice: "3d4", dmgMod: null, dmgType: "plasma", bulk: 3, special: "Rapid Fire — 2 actions, 10ft cone, Physical save vs you or 3d4 plasma." },
  { name: "Pulse Repeater II", category: "Blasters", tier: "superior", cost: 580, action: ">", atkAttr: "Agility", range: "45ft", dice: "3d8", dmgMod: null, dmgType: "plasma", bulk: 4, est: true },
  { name: "Charge Repeater II", category: "Blasters", tier: "superior", cost: 680, action: ">", atkAttr: "Agility", range: "45ft", dice: "3d8", dmgMod: null, dmgType: "ion", bulk: 4, est: true },
  { name: "Echo Repeater II", category: "Blasters", tier: "superior", cost: 680, action: ">", atkAttr: "Agility", range: "45ft", dice: "3d8", dmgMod: null, dmgType: "sonic", bulk: 4, est: true },
  { name: "Pulse Shotgun II", category: "Blasters", tier: "superior", cost: 580, action: ">", atkAttr: "Agility", range: "10ft", dice: "3d10", dmgMod: null, dmgType: "plasma", bulk: 5, est: true },
  { name: "Charge Shotgun II", category: "Blasters", tier: "superior", cost: 580, action: ">", atkAttr: "Agility", range: "10ft", dice: "3d10", dmgMod: null, dmgType: "ion", bulk: 5, est: true },
  { name: "Echo Shotgun II", category: "Blasters", tier: "superior", cost: 580, action: ">", atkAttr: "Agility", range: "10ft", dice: "2d10", dmgMod: null, dmgType: "sonic", bulk: 5, est: true },
  { name: "Pulse Carbine II", category: "Blasters", tier: "superior", cost: 300, action: ">", atkAttr: "Agility", range: "40ft", dice: "3d8", dmgMod: null, dmgType: "plasma", bulk: 3, est: true },
  { name: "Charge Carbine II", category: "Blasters", tier: "superior", cost: 500, action: ">", atkAttr: "Agility", range: "40ft", dice: "3d8", dmgMod: null, dmgType: "ion", bulk: 3, est: true },
  { name: "Echo Carbine II", category: "Blasters", tier: "superior", cost: 500, action: ">", atkAttr: "Agility", range: "40ft", dice: "3d8", dmgMod: null, dmgType: "sonic", bulk: 3, est: true },
  { name: "Pulse Cannon II", category: "Blasters", tier: "superior", cost: 280, action: ">", atkAttr: "Agility", range: "45ft", dice: "3d8", dmgMod: null, dmgType: "plasma", bulk: 4, est: true },
  { name: "Charge Cannon II", category: "Blasters", tier: "superior", cost: 480, action: ">", atkAttr: "Agility", range: "45ft", dice: "3d8", dmgMod: null, dmgType: "ion", bulk: 4, est: true },
  { name: "Echo Cannon II", category: "Blasters", tier: "superior", cost: 480, action: ">", atkAttr: "Agility", range: "45ft", dice: "3d8", dmgMod: null, dmgType: "sonic", bulk: 4, est: true },
  { name: "Pulse Rifle II", category: "Blasters", tier: "superior", cost: 350, action: ">>", atkAttr: "Agility", range: "75ft (unusable within 15ft)", dice: "3d12", dmgMod: null, dmgType: "plasma", bulk: 6 },
  { name: "Charge Rifle II", category: "Blasters", tier: "superior", cost: 650, action: ">>", atkAttr: "Agility", range: "75ft (unusable within 15ft)", dice: "3d12", dmgMod: null, dmgType: "ion", bulk: 6 },
  { name: "Echo Rifle II", category: "Blasters", tier: "superior", cost: 650, action: ">>", atkAttr: "Agility", range: "75ft (unusable within 15ft)", dice: "3d12", dmgMod: null, dmgType: "sonic", bulk: 6 },
  // ===== SUPERIOR BOWS =====
  { name: "Handbow II", category: "Bows", tier: "superior", cost: 290, action: ">", atkAttr: "Agility", range: "20ft", dice: "2d4", dmgMod: "Agility", dmgType: "piercing", bulk: 2, est: true, special: "Flurry — dual-wielded, two attacks at 20ft; each hit deals 2d4 piercing (no modifier)." },
  { name: "Shortbow II", category: "Bows", tier: "superior", cost: 320, action: ">", atkAttr: "Agility", range: "35ft", dice: "2d6", dmgMod: "Agility", dmgType: "piercing", bulk: 3 },
  { name: "Longbow II", category: "Bows", tier: "superior", cost: 350, action: ">", atkAttr: "Agility", range: "45ft", dice: "2d8", dmgMod: "Agility", dmgType: "piercing", bulk: 4 },
  { name: "Crossbow II", category: "Bows", tier: "superior", cost: 450, action: ">>", atkAttr: "Agility", range: "50ft", dice: "2d10", dmgMod: "Agility", dmgType: "piercing", bulk: 4, est: true },
  // ===== SUPERIOR POLEARMS =====
  { name: "Longstaff II", category: "Polearms", tier: "superior", cost: 280, action: ">", atkAttr: "Body", range: "10ft", dice: "2d8", dmgMod: "Body", dmgType: "bludgeoning", bulk: 3, est: true },
  { name: "Spear II", category: "Polearms", tier: "superior", cost: 380, action: ">", atkAttr: "Agility", range: "10ft", dice: "2d10", dmgMod: "Agility", dmgType: "piercing", bulk: 3, est: true },
  { name: "Glaive II", category: "Polearms", tier: "superior", cost: 450, action: ">", atkAttr: "Body", range: "10ft", dice: "2d10", dmgMod: "Body", dmgType: "slashing", bulk: 6, est: true },
];

const STARTING_WEAPON_CHOICES = ["Dagger", "Pulse Pistol", "Handbow", "Shortstaff"];
const GEAR_NOTE = "A few weapon bulk values and standard-tier Cannon flavor text weren't explicitly listed in the source material (marked \u2020) and were estimated by analogy to similar listed gear.";

/* ---------------------------------- ARMOR ---------------------------------- */
const ARMOR = [
  { name: "Light armor", bonus: 2, bodyReq: 4, bulk: 2 },
  { name: "Field armor", bonus: 4, bodyReq: 6, bulk: 3 },
  { name: "Battle armor", bonus: 6, bodyReq: 8, bulk: 5 },
  { name: "Heavy armor", bonus: 8, bodyReq: 10, bulk: 6 },
];

/* ------------------------------- ARMOR SETS -------------------------------- */
/* Named superior armor from the Galactic Guide. Each is built on one of the four
   base tiers (same AR bonus + Body requirement + bulk) but adds its own resistance,
   vulnerability, or Adept bonus. */
const ARMOR_SETS = [
  { name: "Assassin Armor", baseTier: "Field armor", cost: 1400, text: "Resistance score of 4 against poison and acid damage. Inept with Persuasion checks." },
  { name: "Infiltrator Outfit", baseTier: "Field armor", cost: 900, text: "Adept with Stealth and Technique checks." },
  { name: "Pap-Boy Cloak", baseTier: "Field armor", cost: 2000, text: "Use an action to become invisible for 1 minute (once per long rest). While invisible, attack rolls against you are rolled twice, using the lower result." },
  { name: "Beast Hide", baseTier: "Field armor", cost: 1500, text: "Resistance score of 2 against slashing, bludgeoning, and piercing damage. Adept with Intimidation checks." },
  { name: "Dire Hound Hide", baseTier: "Field armor", cost: 1700, text: "Adept with Spiritual saving rolls. Resistance score of 2 against necrotic damage." },
  { name: "Tribal Wraps", baseTier: "Field armor", cost: 1300, text: "Adept with Physical saving rolls." },
  { name: "Headhunter Gear", baseTier: "Battle armor", cost: 2280, text: "Resistance score of 4 against plasma and slashing damage. Adept with Persuasion and Intimidation checks." },
  { name: "Raider Gear", baseTier: "Battle armor", cost: 2210, text: "Resistance score of 4 against plasma and piercing damage. Adept with Fortuity checks." },
  { name: "Mirgu Plating", baseTier: "Battle armor", cost: 2300, text: "Immune to poison damage." },
  { name: "Mantor-Make", baseTier: "Battle armor", cost: 2500, text: "Immune to slashing damage. Vulnerability score of 2 against fire damage." },
  { name: "Hunting Gear", baseTier: "Battle armor", cost: 2400, text: "Resistance score of 3 against slashing, piercing, and bludgeoning damage. Adept with Perception and Investigation checks." },
  { name: "Armored Robes", baseTier: "Battle armor", cost: 2600, text: "Resistance score of 3 against fire, frost, and force damage. Adept with Spiritual saving rolls." },
  { name: "Soldier Set", baseTier: "Heavy armor", cost: 2700, text: "Resistance score of 4 against plasma, ion, and sonic damage." },
  { name: "Darkmatter Armor", baseTier: "Heavy armor", cost: 3000, text: "Resistance score of 4 against necrotic, radiant, and unknown damage." },
  { name: "Salvaged Plating", baseTier: "Heavy armor", cost: 2900, text: "Resistance score of 4 against psychic, necrotic, radiant, and unknown damage. Vulnerability score of 4 against ion damage." },
];

/* ------------------------------ MODIFICATIONS ------------------------------ */
/* Installable on superior-tier gear only. Reference only — the sheet doesn't
   auto-apply these to attack/damage math, since a mod attaches to one specific
   item rather than a whole category. */
const MODIFICATIONS = [
  { name: "Suppressor", category: "Weapon", cost: 900, fitsText: "Any superior Blaster", text: "Silences the weapon." },
  { name: "Scope", category: "Weapon", cost: 1200, fitsText: "Any superior Blaster", text: "Increases the weapon's range by 20ft." },
  { name: "Receiver", category: "Weapon", cost: 1500, fitsText: "Any superior Blaster", text: "Damage rolls are made twice, using the higher result." },
  { name: "Calibrator", category: "Weapon", cost: 1700, fitsText: "Any superior Blaster (not with Flurry)", text: "Add your Agility score (not modifier) to attack rolls." },
  { name: "Sharpened Edge", category: "Weapon", cost: 1200, fitsText: "Any superior Blade", text: "Damage rolls are made twice, using the higher result." },
  { name: "Energized Edge", category: "Weapon", cost: 2000, fitsText: "Any superior Blade", text: "Replaces slashing damage with plasma or ion damage." },
  { name: "Reformed Hilt", category: "Weapon", cost: 900, fitsText: "Any superior Blade", text: "Add your Agility modifier to attack rolls instead of your Body modifier." },
  { name: "Plasma Wiring", category: "Weapon", cost: 1000, fitsText: "Any superior Bow", text: "Replaces piercing damage with plasma damage." },
  { name: "Ion Wiring", category: "Weapon", cost: 1000, fitsText: "Any superior Bow", text: "Replaces piercing damage with ion damage." },
  { name: "Longer Handle", category: "Weapon", cost: 500, fitsText: "Any superior Polearm", text: "Increases the weapon's range by 5ft." },
  { name: "Sharpened Tip", category: "Weapon", cost: 1000, fitsText: "Superior Spears and Glaives", text: "Damage rolls are made twice, using the higher result." },
  { name: "Adhesive Underlay", category: "Armor", cost: 800, fitsText: "Any armor set", text: "Resistance score of 2 against acid, fire, and poison damage." },
  { name: "Padded Overlay", category: "Armor", cost: 900, fitsText: "Battle and Heavy armor only", text: "Resistance score of 2 against slashing, piercing, and bludgeoning damage." },
  { name: "Reinforced Plating", category: "Armor", cost: 1200, fitsText: "Battle and Heavy armor only", text: "Resistance score of 4 against slashing, piercing, plasma, and bludgeoning damage." },
  { name: "Environmental Overlay", category: "Armor", cost: 1100, fitsText: "Any armor set", text: "Resistance score of 4 against fire, frost, and force damage." },
];

/* ---------------------------------- ITEMS ---------------------------------- */
const ITEMS = [
  // Healing
  { name: "Medicine pack", category: "Healing", tier: "standard", cost: 50, bulk: 1, text: "On use: 1d6 healing." },
  { name: "Health pack", category: "Healing", tier: "standard", cost: 70, bulk: 1, text: "On use: 2d6 healing." },
  { name: "Repair kit", category: "Healing", tier: "standard", cost: 90, bulk: 2, text: "On use: a construct regains 2d6 health." },
  { name: "Vessel repair kit", category: "Healing", tier: "standard", cost: 250, bulk: 1, text: "On use: a Vessel regains 3d6 health." },
  { name: "Medicine pack II", category: "Healing", tier: "superior", cost: 250, bulk: 1, text: "On use: a creature receives 2d8 healing." },
  { name: "Health pack II", category: "Healing", tier: "superior", cost: 370, bulk: 1, text: "On use: a creature receives 3d8 healing." },
  { name: "Repair kit II", category: "Healing", tier: "superior", cost: 90, bulk: 2, text: "On use: a construct receives 3d6 healing." },
  { name: "Vessel repair kit II", category: "Healing", tier: "superior", cost: 650, bulk: 1, text: "On use: a Vessel receives 4d8 healing." },
  // Protective
  { name: "Physical shield", category: "Protective", tier: "standard", cost: 45, bulk: 1, text: "For 1 minute, subtract 1d4 from physical damage types." },
  { name: "Energy shield", category: "Protective", tier: "standard", cost: 50, bulk: 1, text: "For 1 minute, subtract 1d4 from energy damage types." },
  { name: "Elemental shield", category: "Protective", tier: "standard", cost: 75, bulk: 1, text: "For 1 minute, subtract 1d4 from elemental damage types." },
  { name: "Physical shield II", category: "Protective", tier: "superior", cost: 245, bulk: 1, text: "For 1 minute, subtract 2d4 from physical damage types." },
  { name: "Energy shield II", category: "Protective", tier: "superior", cost: 250, bulk: 1, text: "For 1 minute, subtract 2d4 from energy damage types." },
  { name: "Elemental shield II", category: "Protective", tier: "superior", cost: 275, bulk: 1, text: "For 1 minute, subtract 2d4 from elemental damage types." },
  // Enhancing
  { name: "Stimulant", category: "Enhancing", tier: "standard", cost: 100, bulk: 1, text: "For 1 minute, Body or Agility score is increased by 1." },
  { name: "Concentrator", category: "Enhancing", tier: "standard", cost: 120, bulk: 1, text: "For 1 minute, Mind score is increased by 1." },
  { name: "Psychedelic", category: "Enhancing", tier: "standard", cost: 130, bulk: 1, text: "For 1 minute, Spirit or Luck score is increased by 1." },
  { name: "Stimulant II", category: "Enhancing", tier: "superior", cost: 300, bulk: 1, text: "For 1 minute, Body or Agility score is increased by 2." },
  { name: "Concentrator II", category: "Enhancing", tier: "superior", cost: 320, bulk: 1, text: "For 1 minute, Mind score is increased by 2." },
  { name: "Psychedelic II", category: "Enhancing", tier: "superior", cost: 330, bulk: 1, text: "For 1 minute, Spirit or Luck score is increased by 2." },
  // Explosives
  { name: "Plasma-Grenade", category: "Explosives", tier: "standard", cost: 250, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 2d10 plasma damage." },
  { name: "Ion-Grenade", category: "Explosives", tier: "standard", cost: 250, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 2d10 ion damage." },
  { name: "Sonic-Grenade", category: "Explosives", tier: "standard", cost: 250, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 2d10 sonic damage." },
  { name: "Fire-Grenade", category: "Explosives", tier: "standard", cost: 350, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 2d10 fire damage." },
  { name: "Frost-Grenade", category: "Explosives", tier: "standard", cost: 250, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 2d10 frost damage." },
  { name: "Acid-Grenade", category: "Explosives", tier: "standard", cost: 250, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 2d10 acid damage." },
  { name: "Plasma-Mine", category: "Explosives", tier: "standard", cost: 300, bulk: 1, text: "Place within 5ft; 5ft detonation radius. A target entering range makes a Physical saving roll against you or takes 3d12 plasma damage." },
  { name: "Ion-Mine", category: "Explosives", tier: "standard", cost: 320, bulk: 1, text: "Place within 5ft; 5ft detonation radius. A target entering range makes a Physical saving roll against you or takes 3d12 ion damage." },
  { name: "Sonic-Mine", category: "Explosives", tier: "standard", cost: 350, bulk: 1, text: "Place within 5ft; 5ft detonation radius. A target entering range makes a Physical saving roll against you or takes 3d12 sonic damage." },
  { name: "Poison-Mine", category: "Explosives", tier: "standard", cost: 400, bulk: 1, text: "Place within 5ft; 5ft detonation radius. A target entering range makes a Physical saving roll against you or takes 3d12 poison damage." },
  { name: "Plasma-Grenade II", category: "Explosives", tier: "superior", cost: 450, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 3d10 plasma damage." },
  { name: "Ion-Grenade II", category: "Explosives", tier: "superior", cost: 650, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 3d10 ion damage." },
  { name: "Sonic-Grenade II", category: "Explosives", tier: "superior", cost: 650, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 3d10 sonic damage." },
  { name: "Fire-Grenade II", category: "Explosives", tier: "superior", cost: 650, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 3d10 fire damage." },
  { name: "Frost-Grenade II", category: "Explosives", tier: "superior", cost: 650, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 3d10 frost damage." },
  { name: "Acid-Grenade II", category: "Explosives", tier: "superior", cost: 650, bulk: 1, text: "Throw at a point within 25ft; 10ft-radius blast. Targets make a Physical saving roll against you or take 3d10 acid damage." },
];

const STARTING_KIT = { gc: 50, extras: ["Light armor", "A starmap leading to your origin (bulk 3)", "Your chosen starting weapon"] };

const BULK_NOTE = "Carrying capacity equals your Body score. Bulk only applies to unequipped items. A few weapons not given an explicit bulk in the book (marked \u2020) were estimated by analogy to similar listed gear.";

window.TB = {
  ATTRIBUTES, ATTR_BLURB, scoreToMod, fmtMod,
  SKILLS, ADEPT_DICE, INEPT_DICE, diceForLevel,
  XP_TABLE, DR_TABLE, DAMAGE_TYPES, ACTION_ICONS, EXHAUSTION_TABLE,
  SPECIES, ORIGINS, ROLES, PATHS, PATHWAYS,
  ADVANCEMENTS, MUTATIONS, POWERS,
  WEAPONS, STARTING_WEAPON_CHOICES, ARMOR, ARMOR_SETS, MODIFICATIONS, ITEMS,
  STARTING_KIT, BULK_NOTE, GEAR_NOTE,
};
