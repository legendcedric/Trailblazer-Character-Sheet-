/* ==========================================================================
   TRAILBLAZER CHARACTER SHEET — application logic
   Single-character, single-page sheet. State lives in `state`, persisted to
   localStorage. Every render() call rebuilds the DOM from state, so state is
   always the single source of truth.
   ========================================================================== */

const D = window.TB;
const STORAGE_KEY = "trailblazer-sheet-v1";

function freshState() {
  return {
    name: "",
    build: { species: "", origin: "", role: "", path: "", pathway: "", level: 1, xp: 0 },
    attrs: { Agility: 0, Body: 0, Mind: 0, Spirit: 0, Luck: 0 },
    choices: { attrRaise: [], adeptSkill: [], adeptSave: [] },
    skillNeutralized: [],
    skillBonusAdept: [],
    saveBound: null,
    advancements: {},
    additionalPath: null,
    additionalPathPathway: null,
    mutations: [],
    powersKnown: [],
    powersReadied: [],
    powerSlotsUsed: { 1: 0, 2: 0, 3: 0 },
    resourceAdj: { ap: 0, mp: 0, pp: 0 },
    hp: { max: 0, current: 0 },
    exhaustion: 0,
    armorEquipped: null,
    attacks: [],
    inventory: [],
    enraged: false,
    notes: "",
  };
}

let state = loadState();

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return freshState();
    const parsed = JSON.parse(raw);
    return Object.assign(freshState(), parsed);
  } catch (e) {
    return freshState();
  }
}
function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    /* running somewhere storage isn't available — sheet still works this session */
  }
}

/* ------------------------------ lookups -------------------------------- */
const bySpecies = (n) => D.SPECIES.find((s) => s.name === n);
const byOrigin = (n) => D.ORIGINS.find((s) => s.name === n);
const byRole = (n) => D.ROLES.find((s) => s.name === n);
const byPath = (n) => D.PATHS.find((s) => s.name === n);
const byPathway = (n) => D.PATHWAYS.find((s) => s.name === n);
const byWeapon = (n) => D.WEAPONS.find((s) => s.name === n);
const byArmor = (n) => D.ARMOR.find((s) => s.name === n);
const byArmorSet = (n) => D.ARMOR_SETS.find((s) => s.name === n);
const byModification = (n) => D.MODIFICATIONS.find((s) => s.name === n);
const byItem = (n) => D.ITEMS.find((s) => s.name === n);
const byPower = (n) => D.POWERS.find((s) => s.name === n);
const byMutation = (n) => D.MUTATIONS.find((s) => s.name === n);
const byAdvancement = (n) => D.ADVANCEMENTS.find((s) => s.name === n);

function currentSpecies() { return bySpecies(state.build.species); }
function currentOrigin() { return byOrigin(state.build.origin); }
function currentRole() { return byRole(state.build.role); }
function currentPath() { return byPath(state.build.path); }
function currentPathway() { return byPathway(state.build.pathway); }
function pathwaysForPath(pathName) { return D.PATHWAYS.filter((pw) => pw.parentPath === pathName); }
function level() { return Number(state.build.level) || 1; }

/* Merged armor lookup — a base tier (Light/Field/Battle/Heavy) or a named
   Galactic Guide set built on one of those tiers. Always returns the same shape. */
function armorLookup(name) {
  const base = byArmor(name);
  if (base) return { name: base.name, bonus: base.bonus, bodyReq: base.bodyReq, bulk: base.bulk, baseTier: base.name, isSet: false };
  const set = byArmorSet(name);
  if (set) {
    const tier = byArmor(set.baseTier);
    if (!tier) return null;
    return { name: set.name, bonus: tier.bonus, bodyReq: tier.bodyReq, bulk: tier.bulk, baseTier: tier.name, isSet: true, text: set.text };
  }
  return null;
}

/* --------------------------- attribute math ------------------------------ */
function speciesBonus(attr) {
  const sp = currentSpecies();
  return sp && sp.mods[attr] ? sp.mods[attr] : 0;
}
function totalScore(attr) {
  const raised = state.choices.attrRaise.filter((c) => c.attr === attr).length;
  return (Number(state.attrs[attr]) || 0) + speciesBonus(attr) + raised;
}
function mod(attr) { return D.scoreToMod(totalScore(attr)); }

/* ------------------------- progression unlocking -------------------------- */
// All progression rows for a path (defaults to the main path) at or below current level.
function unlockedRows(pathObj) {
  const p = pathObj || currentPath();
  if (!p) return [];
  return p.progression.filter((r) => r.lvl <= level());
}
// pathObj is optional — pass the Additional Path's path object to pull its feature list instead.
function unlockedFeatures(pathObj) {
  const out = [];
  unlockedRows(pathObj).forEach((r) => (r.features || []).forEach((f) => out.push(Object.assign({ lvl: r.lvl }, f))));
  return out;
}
function additionalPathObj() { return state.additionalPath ? byPath(state.additionalPath) : null; }
function grantsOfType(key) {
  // returns [{lvl, ...grant}] for rows whose `grants` object has `key`
  const out = [];
  unlockedRows().forEach((r) => {
    if (r.grants && r.grants[key] !== undefined && r.grants[key] !== false) out.push({ lvl: r.lvl, value: r.grants[key] });
  });
  return out;
}
function earnedPoints(key) {
  // key: 'ap' | 'mp' | 'pp' — numeric grants, summed. Mentalist/Spiritualist grant
  // "half current Mind/Spirit modifier" at a couple of levels instead of a flat number.
  return grantsOfType(key).reduce((sum, g) => {
    if (typeof g.value === "number") return sum + g.value;
    if (g.value === "halfMind") return sum + Math.max(0, Math.floor(mod("Mind") / 2));
    if (g.value === "halfSpirit") return sum + Math.max(0, Math.floor(mod("Spirit") / 2));
    return sum;
  }, 0);
}
function attrRaiseGrantsUnlocked() { return grantsOfType("attrRaise"); }
function adeptSkillGrantsUnlocked() { return grantsOfType("adeptSkillChoice"); }
function adeptSaveGrantsUnlocked() {
  const out = [];
  unlockedRows().forEach((r) => {
    if (r.grants && r.grants.adeptSaveChoice) out.push({ lvl: r.lvl, options: r.grants.adeptSaveChoice });
  });
  return out;
}
// Weapon categories granted automatically (no choice involved) at a given level, e.g. Bloodblade's Bows at Lvl2.
function weaponAddGrants(pathObj) {
  const out = [];
  unlockedRows(pathObj).forEach((r) => { if (r.grants && r.grants.weaponAdd) out.push(r.grants.weaponAdd); });
  return out;
}
function effectiveWeaponProfs(pathObj) {
  const p = pathObj || currentPath();
  if (!p) return [];
  return [...new Set([...p.weapons, ...weaponAddGrants(p)])];
}

/* ------------------------------ skills ------------------------------ */
function baseSkillMap() {
  // returns {skillName: 'adept'|'inept'|'standard'} from origin + role only
  const map = {};
  D.SKILLS.forEach((s) => (map[s.name] = "standard"));
  const applyList = (list, status) => (list || []).forEach((name) => {
    if (map[name] === "standard") map[name] = status;
    else if (map[name] !== status) map[name] = "cancelled"; // hit from both sides
  });
  const o = currentOrigin(), r = currentRole();
  if (o) { applyList(o.adept, "adept"); applyList(o.inept, "inept"); }
  if (r) {
    // role applied after origin so cross-cancellation is caught
    (r.adept || []).forEach((name) => {
      if (map[name] === "inept") map[name] = "cancelled";
      else if (map[name] === "standard") map[name] = "adept";
    });
    (r.inept || []).forEach((name) => {
      if (map[name] === "adept") map[name] = "cancelled";
      else if (map[name] === "standard") map[name] = "inept";
    });
  }
  Object.keys(map).forEach((k) => { if (map[k] === "cancelled") map[k] = "standard"; });
  return map;
}
function finalSkillMap() {
  const map = baseSkillMap();
  state.skillNeutralized.forEach((name) => { if (map[name] === "inept") map[name] = "standard"; });
  const bonusAdept = [...state.skillBonusAdept, ...state.choices.adeptSkill.map((c) => c.skill)];
  bonusAdept.forEach((name) => { if (map[name] !== "inept") map[name] = "adept"; });
  return map;
}

/* -------------------------------- saves -------------------------------- */
function saveAdeptSet() {
  const set = new Set();
  const p = currentPath();
  if (p) set.add(p.save);
  state.choices.adeptSave.forEach((c) => set.add(c.save));
  if (state.saveBound) set.add(state.saveBound);
  return set;
}
function slPhysical() { return 10 + mod("Body") + mod("Agility") + Math.floor(level() / 2); }
function slMental() { return 12 + mod("Mind") + level(); }
function slSpiritual() { return 10 + mod("Spirit") + mod("Luck") + Math.floor(level() / 2); }

/* -------------------------------- combat -------------------------------- */
function highestAttrMod() { return Math.max(...D.ATTRIBUTES.map((a) => mod(a))); }
function armorBonus() {
  const a = armorLookup(state.armorEquipped);
  if (!a) return 0;
  let bonus = a.bonus;
  const p = currentPath();
  if (p && p.name === "Maverick" && a.baseTier === "Field armor") bonus += Math.floor(mod("Agility") / 2);
  return bonus;
}
function unarmoredBonus() {
  if (state.armorEquipped) return 0;
  if (!state.advancements["Unarmored Expertise"]) return 0;
  return Math.floor(highestAttrMod() / 2);
}
function AR() { return 10 + armorBonus() + unarmoredBonus() + level(); }
function hitDieLabel() {
  const p = currentPath();
  return p ? `${p.hitDie} + ${p.hitDieAttr} modifier per level` : "\u2014";
}

/* -------------------------------- bulk -------------------------------- */
function bulkCapacity() { return totalScore("Body"); }
function bulkUsed() {
  return state.inventory.reduce((sum, it) => sum + (it.equipped ? 0 : (Number(it.bulk) || 0) * (Number(it.qty) || 1)), 0);
}

/* -------------------------------- xp -------------------------------- */
function xpRow(lvl) { return D.XP_TABLE.find((r) => r.level === lvl); }
function xpNext() { return xpRow(Math.min(level() + 1, 12)); }
// Highest level whose XP threshold the given total meets or exceeds.
function levelForXp(xp) {
  let lvl = 1;
  D.XP_TABLE.forEach((row) => { if (xp >= row.xp) lvl = row.level; });
  return lvl;
}

/* -------------------------------- resources -------------------------------- */
function resourceKind() {
  const p = currentPath();
  if (!p) return "none";
  return p.resource; // 'mutation' | 'slots' | 'powerpoints' | 'none'
}
function apEarned() { return earnedPoints("ap") + (Number(state.resourceAdj.ap) || 0); }
function mpEarned() { return earnedPoints("mp") + (Number(state.resourceAdj.mp) || 0); }
function ppEarned() { return earnedPoints("pp") + (Number(state.resourceAdj.pp) || 0); }
function apSpent() {
  let n = 0;
  Object.entries(state.advancements).forEach(([name, qty]) => { n += qty; });
  return n;
}
function mpSpent() { return state.mutations.reduce((sum, n) => { const m = byMutation(n); return sum + (m ? m.cost : 0); }, 0); }
function ppSpent() { return state.powersKnown.reduce((sum, n) => { const p = byPower(n); return sum + (p ? p.pp : 0); }, 0); }
function slotTableRow() {
  const p = currentPath();
  if (!p || !p.slotTable) return [0, 0, 0];
  return p.slotTable[Math.min(level(), 12) - 1];
}

/* ============================== RENDERING ================================ */
function el(id) { return document.getElementById(id); }
function opt(value, label, selected) {
  return `<option value="${escapeAttr(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(label)}</option>`;
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function escapeAttr(s) { return escapeHtml(s); }

function render() {
  renderHeader();
  renderChoicePrompts();
  renderAttributes();
  renderSaves();
  renderProficiencies();
  renderSkills();
  renderResources();
  renderAttacks();
  renderFeatures();
  renderInventory();
  renderPowers();
  renderMutations();
  renderNotes();
  saveState();
}

/* --------------------------------- header --------------------------------- */
function renderHeader() {
  el("nameInput").value = state.name;

  el("speciesSelect").innerHTML = `<option value="">\u2014 choose \u2014</option>` + D.SPECIES.map((s) => opt(s.name, s.name, state.build.species)).join("");
  el("originSelect").innerHTML = `<option value="">\u2014 choose \u2014</option>` +
    ["Centaur", "Daark", "Hyll"].map((sys) => `<optgroup label="${sys} System">${D.ORIGINS.filter((o) => o.system === sys).map((o) => opt(o.name, o.name, state.build.origin)).join("")}</optgroup>`).join("");
  el("roleSelect").innerHTML = `<option value="">\u2014 choose \u2014</option>` + D.ROLES.map((r) => opt(r.name, r.name, state.build.role)).join("");
  el("pathSelect").innerHTML = `<option value="">\u2014 choose \u2014</option>` + D.PATHS.map((p) => opt(p.name, p.name, state.build.path)).join("");
  const pwOptions = pathwaysForPath(state.build.path);
  el("pathwaySelect").innerHTML = pwOptions.length
    ? `<option value="">\u2014 choose \u2014</option>` + pwOptions.map((pw) => opt(pw.name, pw.name, state.build.pathway)).join("")
    : `<option value="">Pick a path first</option>`;
  el("pathwaySelect").disabled = pwOptions.length === 0;
  el("levelInput").value = state.build.level;
  el("xpInput").value = state.build.xp;

  const nx = xpNext();
  el("xpNextLabel").textContent = level() >= 12 ? "Max level" : `${nx.xp} XP for level ${nx.level}`;

  const sp = currentSpecies(), or = currentOrigin(), rl = currentRole(), pa = currentPath(), pw = currentPathway();
  const chips = [sp && sp.name, or && or.name, rl && rl.name, pa && pa.name, pw && pw.name].filter(Boolean);
  el("buildChips").innerHTML = chips.length
    ? chips.map((c) => `<span class="chip">${escapeHtml(c)}</span>`).join("")
    : `<span class="chip chip--muted">Pick a species, origin, role, and path below to bring the sheet to life</span>`;

  // vitals strip
  const hp = state.hp;
  const pct = hp.max > 0 ? Math.max(0, Math.min(100, (hp.current / hp.max) * 100)) : 0;
  el("hpBarFill").style.width = pct + "%";
  const fillEl = el("hpBarFill");
  fillEl.classList.remove("hpBarFill--hurt", "hpBarFill--critical");
  if (hp.max > 0 && pct <= 25) fillEl.classList.add("hpBarFill--critical");
  else if (hp.max > 0 && pct <= 60) fillEl.classList.add("hpBarFill--hurt");
  el("hpCurrentInput").value = hp.current;
  el("hpMaxInput").value = hp.max;
  el("arValue").textContent = AR();
  el("slpValue").textContent = slPhysical();
  el("slmValue").textContent = slMental();
  el("slsValue").textContent = slSpiritual();

  const exRow = D.EXHAUSTION_TABLE.find((r) => r.points === state.exhaustion);
  el("exhaustionValue").textContent = state.exhaustion;
  el("exhaustionValue").parentElement.title = exRow ? exRow.effect : "No effect yet";
  el("exhaustionValue").classList.toggle("vital__value--warn", state.exhaustion >= 4 && state.exhaustion < 8);
  el("exhaustionValue").classList.toggle("vital__value--danger", state.exhaustion >= 8);
}

/* ----------------------------- pending choices ----------------------------- */
function renderChoicePrompts() {
  const box = el("choicePrompts");
  const items = [];
  const skillMap = baseSkillMap();

  attrRaiseGrantsUnlocked().forEach((g, i) => {
    const resolved = state.choices.attrRaise[i];
    items.push(`<div class="prompt">
      <span class="prompt__label">Level ${g.lvl} \u2014 permanently raise an attribute score</span>
      <select data-action="choose-attrraise" data-index="${i}">
        <option value="">\u2014 choose \u2014</option>
        ${D.ATTRIBUTES.map((a) => opt(a, `${a} (${totalScore(a)}${resolved && resolved.attr === a ? "" : " \u2192 " + Math.min(12, totalScore(a) + 1)})`, resolved ? resolved.attr : "")).join("")}
      </select></div>`);
  });
  adeptSkillGrantsUnlocked().forEach((g, i) => {
    const resolved = state.choices.adeptSkill[i];
    const options = D.SKILLS.filter((s) => skillMap[s.name] !== "inept");
    items.push(`<div class="prompt">
      <span class="prompt__label">Level ${g.lvl} \u2014 become Adept with a skill of choice</span>
      <select data-action="choose-adeptskill" data-index="${i}">
        <option value="">\u2014 choose \u2014</option>
        ${options.map((s) => opt(s.name, s.name, resolved ? resolved.skill : "")).join("")}
      </select></div>`);
  });
  adeptSaveGrantsUnlocked().forEach((g, i) => {
    const resolved = state.choices.adeptSave[i];
    items.push(`<div class="prompt">
      <span class="prompt__label">Level ${g.lvl} \u2014 become Adept with a saving roll</span>
      <select data-action="choose-adeptsave" data-index="${i}">
        <option value="">\u2014 choose \u2014</option>
        ${g.options.map((s) => opt(s, s, resolved ? resolved.save : "")).join("")}
      </select></div>`);
  });
  if (state.advancements["Additional Path"]) {
    const otherPaths = D.PATHS.filter((p) => p.name !== state.build.path);
    items.push(`<div class="prompt">
      <span class="prompt__label">Additional Path advancement \u2014 choose the secondary path to claim features from</span>
      <select data-action="choose-additionalpath">
        <option value="">\u2014 choose \u2014</option>
        ${otherPaths.map((p) => opt(p.name, p.name, state.additionalPath || "")).join("")}
      </select></div>`);
    if (state.additionalPath) {
      const pwOptions = pathwaysForPath(state.additionalPath);
      items.push(`<div class="prompt">
        <span class="prompt__label">Additional Path advancement \u2014 choose one of ${escapeHtml(state.additionalPath)}'s pathways</span>
        <select data-action="choose-additionalpathpathway">
          <option value="">\u2014 choose \u2014</option>
          ${pwOptions.map((pw) => opt(pw.name, pw.name, state.additionalPathPathway || "")).join("")}
        </select></div>`);
    }
  }

  box.innerHTML = items.length ? items.join("") : "";
  box.style.display = items.length ? "grid" : "none";
}

/* ------------------------------- attributes ------------------------------- */
function renderAttributes() {
  const box = el("attrBox");
  box.innerHTML = D.ATTRIBUTES.map((a) => {
    const base = Number(state.attrs[a]) || 0;
    const bonus = speciesBonus(a);
    const raised = state.choices.attrRaise.filter((c) => c.attr === a).length;
    const total = totalScore(a);
    return `<div class="attrCard">
      <div class="attrCard__name">${a}</div>
      <div class="attrCard__blurb">${D.ATTR_BLURB[a]}</div>
      <div class="attrCard__row">
        <label>Base <input type="number" min="0" max="12" data-action="set-attr" data-attr="${a}" value="${base}"></label>
        <span class="attrCard__bonus" title="Species + attribute-raise bonuses">${bonus + raised >= 0 ? "+" : ""}${bonus + raised}</span>
      </div>
      <div class="attrCard__total">
        <span class="attrCard__score">${total}</span>
        <span class="attrCard__mod">${D.fmtMod(D.scoreToMod(total))}</span>
      </div>
    </div>`;
  }).join("");
}

/* ---------------------------------- saves ---------------------------------- */
function renderSaves() {
  const adeptSet = saveAdeptSet();
  const rows = [
    { name: "Physical", sl: slPhysical(), formula: "10 + Body mod + Agility mod + \u00bd level" },
    { name: "Mental", sl: slMental(), formula: "12 + Mind mod + level" },
    { name: "Spiritual", sl: slSpiritual(), formula: "10 + Spirit mod + Luck mod + \u00bd level" },
  ];
  el("savesBox").innerHTML = rows.map((r) => {
    const isAdept = adeptSet.has(r.name);
    const dice = isAdept ? D.diceForLevel(D.ADEPT_DICE, level()) : null;
    return `<div class="saveRow">
      <div class="saveRow__name">${r.name}${isAdept ? '<span class="badge badge--adept">Adept</span>' : ""}</div>
      <div class="saveRow__sl" title="${r.formula}">SL ${r.sl}</div>
      <div class="saveRow__dice">${dice ? "+" + dice + " Adept dice" : "\u2014"}</div>
    </div>`;
  }).join("") + `
    <label class="checkline"><input type="checkbox" data-action="toggle-savebound" ${state.saveBound ? "checked" : ""}> Save Bound advancement purchased
      ${state.saveBound !== null ? `<select data-action="set-savebound">${["Physical","Mental","Spiritual"].map((s) => opt(s, s, state.saveBound)).join("")}</select>` : ""}
    </label>`;
}

/* ------------------------------ proficiencies ------------------------------ */
function renderProficiencies() {
  const sp = currentSpecies(), pa = currentPath();
  const box = el("profBox");
  if (!sp && !pa) { box.innerHTML = `<p class="muted">Species and path details will show up here.</p>`; return; }
  box.innerHTML = `
    ${pa ? `<div class="profRow"><span>Weapon proficiency</span><strong>${effectiveWeaponProfs(pa).join(", ")}</strong></div>
            <div class="profRow"><span>Hit dice</span><strong>${hitDieLabel()}</strong></div>` : ""}
    ${sp ? `<div class="profRow"><span>Languages</span><strong>${sp.languages.join(", ")}</strong></div>
            <div class="profRow"><span>Resistant to</span><strong class="tag--resist">${sp.resist.join(", ")}</strong></div>
            <div class="profRow"><span>Vulnerable to</span><strong class="tag--vuln">${sp.vuln.join(", ")}</strong></div>
            <div class="profRow"><span>Innate \u2014 ${sp.innate.name}</span><strong>${sp.innate.text}</strong></div>` : ""}`;
}

/* ---------------------------------- skills ---------------------------------- */
function renderSkills() {
  const map = finalSkillMap();
  el("skillsBox").innerHTML = D.SKILLS.map((s) => {
    const status = map[s.name];
    const m = mod(s.attr);
    const dice = status === "adept" ? "+" + D.diceForLevel(D.ADEPT_DICE, level()) : status === "inept" ? "\u2212" + D.diceForLevel(D.INEPT_DICE, level()) : "\u2014";
    return `<div class="skillRow skillRow--${status}">
      <span class="skillRow__name">${s.name}</span>
      <span class="skillRow__attr">${s.attr}</span>
      <span class="skillRow__badge">${status === "adept" ? "Adept" : status === "inept" ? "Inept" : ""}</span>
      <span class="skillRow__mod">${D.fmtMod(m)}</span>
      <span class="skillRow__dice">${dice}</span>
    </div>`;
  }).join("");
}

/* -------------------------------- resources -------------------------------- */
function renderResources() {
  const kind = resourceKind();
  const ap = apEarned(), apUsed = apSpent();
  const resLine = (label, used, earned) => `<div class="resRow${used > earned ? " resRow--over" : ""}"><span>${label}</span><strong>${used} / ${earned}</strong></div>`;
  let html = resLine("Advancement Points", apUsed, ap);
  if (kind === "mutation") html += resLine("Mutation Points", mpSpent(), mpEarned());
  if (kind === "powerpoints") html += resLine("Power Points (known powers)", ppSpent(), ppEarned());
  el("resourceTotals").innerHTML = html;

  // manual adjustment fields
  el("apAdj").value = state.resourceAdj.ap;
  el("mpAdjWrap").style.display = kind === "mutation" ? "" : "none";
  el("ppAdjWrap").style.display = kind === "powerpoints" ? "" : "none";
  el("mpAdj").value = state.resourceAdj.mp;
  el("ppAdj").value = state.resourceAdj.pp;

  // power slots
  const slotBox = el("slotsBox");
  if (kind === "slots" || kind === "powerpoints") {
    const row = slotTableRow();
    slotBox.style.display = "";
    slotBox.innerHTML = [1, 2, 3].map((tier) => {
      const max = row[tier - 1] || 0;
      if (max === 0) return "";
      const used = Math.min(state.powerSlotsUsed[tier] || 0, max);
      let dots = "";
      for (let i = 0; i < max; i++) {
        dots += `<button class="slotDot ${i < used ? "slotDot--used" : ""}" data-action="toggle-slot" data-tier="${tier}" data-idx="${i}" title="Level ${tier} power slot"></button>`;
      }
      return `<div class="slotTier"><span class="slotTier__label">Lv${tier}</span><div class="slotTier__dots">${dots}</div></div>`;
    }).join("") + `<button class="btn btn--ghost btn--small" data-action="reset-slots">Long rest (reset slots)</button>`;
  } else {
    slotBox.style.display = "none";
    slotBox.innerHTML = "";
  }

  // purchased advancements
  el("advancementsList").innerHTML = Object.keys(state.advancements).length
    ? Object.entries(state.advancements).map(([name, qty]) => {
        const a = byAdvancement(name);
        return `<div class="pillRow">
          <span>${escapeHtml(name)}${qty > 1 ? ` \u00d7${qty}` : ""}</span>
          <span class="pillRow__cost">${qty} AP</span>
          <button class="iconBtn" data-action="remove-advancement" data-name="${escapeAttr(name)}" title="Remove one">\u2212</button>
        </div>`;
      }).join("")
    : `<p class="muted">None purchased yet.</p>`;
}

/* --------------------------------- attacks --------------------------------- */
function renderAttacks() {
  el("attacksBox").innerHTML = state.attacks.length ? state.attacks.map((a, i) => {
    const w = byWeapon(a.name);
    if (!w) return "";
    const atkMod = mod(w.atkAttr);
    const isAdeptWeapon = effectiveWeaponProfs().includes(w.category);
    const adeptDice = isAdeptWeapon ? "+" + D.diceForLevel(D.ADEPT_DICE, level()) : "";
    const dmgMod = w.dmgMod ? D.fmtMod(mod(w.dmgMod)) : "";
    return `<div class="attackRow">
      <div class="attackRow__name">${w.name}<span class="attackRow__cat">${w.category}</span></div>
      <div class="attackRow__stat"><label>Atk</label>${D.fmtMod(atkMod)} ${adeptDice}</div>
      <div class="attackRow__stat"><label>Range</label>${w.range}</div>
      <div class="attackRow__stat"><label>Damage</label>${w.dice}${dmgMod ? " " + dmgMod : ""} ${w.dmgType}</div>
      <div class="attackRow__stat"><label>Action</label>${w.action || "\u2014"}</div>
      <button class="iconBtn" data-action="remove-attack" data-index="${i}" title="Remove">\u2715</button>
    </div>${w.special ? `<div class="attackRow__special">${w.special}</div>` : ""}`;
  }).join("") : `<p class="muted">No weapons equipped yet.</p>`;
}

/* --------------------------------- features --------------------------------- */
function featureRowHtml(f) {
  return `<div class="featureRow"><div class="featureRow__head"><strong>${f.name}</strong><span>Lv${f.lvl}${f.action ? " \u00b7 " + f.action : ""}</span></div><p>${f.text}</p></div>`;
}
function renderFeatures() {
  const pw = currentPathway();
  const feats = unlockedFeatures().concat(pw ? unlockedFeatures(pw) : []).sort((a, b) => a.lvl - b.lvl);
  const sp = currentSpecies();
  let html = "";
  if (sp) html += `<div class="featureRow"><div class="featureRow__head"><strong>${sp.innate.name}</strong><span>Species</span></div><p>${sp.innate.text}</p></div>`;
  feats.forEach((f) => { html += featureRowHtml(f); });

  const ap = additionalPathObj();
  if (ap) {
    const apPathway = state.additionalPathPathway ? byPathway(state.additionalPathPathway) : null;
    const apFeats = unlockedFeatures(ap).concat(apPathway ? unlockedFeatures(apPathway) : []).sort((a, b) => a.lvl - b.lvl);
    html += `<div class="featureRow featureRow--secondary">
      <div class="featureRow__head"><strong>${ap.name}${apPathway ? " \u2014 " + apPathway.name : ""}</strong><span>Additional Path advancement</span></div>
      <p>${ap.blurb}</p>
    </div>`;
    apFeats.forEach((f) => { html += featureRowHtml(f); });
    if (!apFeats.length) html += `<p class="muted">No features unlock at your current level yet.</p>`;
  }

  el("featuresBox").innerHTML = html || `<p class="muted">Pick a path to see class features unlock here as you level up.</p>`;
}

/* --------------------------------- inventory --------------------------------- */
function renderInventory() {
  const setsByTier = (tier) => D.ARMOR_SETS.filter((s) => s.baseTier === tier);
  el("armorSelect").innerHTML = `<option value="">None equipped</option>` + D.ARMOR.map((a) => {
    const sets = setsByTier(a.name);
    const base = opt(a.name, `${a.name} (+${a.bonus} AR, needs ${a.bodyReq} Body)`, state.armorEquipped);
    if (!sets.length) return base;
    return `<optgroup label="${escapeAttr(a.name)}">${base}${sets.map((s) => opt(s.name, `\u2003${s.name} (+${a.bonus} AR)`, state.armorEquipped)).join("")}</optgroup>`;
  }).join("");
  const equippedInfo = armorLookup(state.armorEquipped);
  el("armorSetNote").textContent = equippedInfo && equippedInfo.isSet ? equippedInfo.text : "";
  el("armorSetNote").style.display = equippedInfo && equippedInfo.isSet ? "" : "none";

  const cap = bulkCapacity(), used = bulkUsed();
  el("bulkMeter").textContent = `${used} / ${cap} bulk`;
  el("bulkMeter").classList.toggle("bulkMeter--over", used > cap);

  el("inventoryList").innerHTML = state.inventory.length ? state.inventory.map((it, i) => `
    <div class="invRow">
      <span class="invRow__name">${escapeHtml(it.name)}${it.qty > 1 ? ` \u00d7${it.qty}` : ""}</span>
      <span class="invRow__note">${escapeHtml(it.note || "")}</span>
      <label class="invRow__equip"><input type="checkbox" data-action="toggle-equipped" data-index="${i}" ${it.equipped ? "checked" : ""}> equipped</label>
      <span class="invRow__bulk">${it.equipped ? "\u2014" : (Number(it.bulk) || 0) * (Number(it.qty) || 1)} bulk</span>
      <button class="iconBtn" data-action="remove-inventory" data-index="${i}" title="Remove">\u2715</button>
    </div>`).join("") : `<p class="muted">Nothing carried yet \u2014 add gear below.</p>`;
}

/* ---------------------------------- powers ---------------------------------- */
function renderPowers() {
  const wrap = el("powersSection");
  const kind = resourceKind();
  if (kind !== "powerpoints") { wrap.style.display = "none"; return; }
  wrap.style.display = "";
  const readiedCap = totalScore("Mind");
  el("readiedCount").textContent = `${state.powersReadied.length} / ${readiedCap} readied (cap = Mind score)`;
  el("powersKnownList").innerHTML = state.powersKnown.length ? state.powersKnown.map((name) => {
    const p = byPower(name);
    if (!p) return "";
    const readied = state.powersReadied.includes(name);
    return `<div class="powerRow">
      <div class="powerRow__head">
        <strong>${p.name}</strong>
        <span class="tag">${p.discipline} \u00b7 Lv${p.level}</span>
        <span class="tag">${p.pp} PP</span>
        <span class="tag">${p.action || "\u2014"}</span>
        <span class="tag">${p.range}</span>
      </div>
      <p>${p.text}</p>
      ${p.heighten ? `<ul class="heightenList">${p.heighten.map((h) => `<li>${h}</li>`).join("")}</ul>` : ""}
      <div class="powerRow__actions">
        <label class="checkline"><input type="checkbox" data-action="toggle-readied" data-name="${escapeAttr(name)}" ${readied ? "checked" : ""}> Ready</label>
        <button class="iconBtn" data-action="remove-power" data-name="${escapeAttr(name)}" title="Forget">\u2715</button>
      </div>
    </div>`;
  }).join("") : `<p class="muted">No powers known yet \u2014 spend Power Points below.</p>`;
}

/* --------------------------------- mutations --------------------------------- */
function renderMutations() {
  const wrap = el("mutationsSection");
  if (resourceKind() !== "mutation") { wrap.style.display = "none"; return; }
  wrap.style.display = "";
  el("enragedToggle").checked = state.enraged;
  el("mutationsKnownList").innerHTML = state.mutations.length ? state.mutations.map((name) => {
    const m = byMutation(name);
    if (!m) return "";
    return `<div class="powerRow">
      <div class="powerRow__head"><strong>${m.name}</strong><span class="tag">${m.cost} MP</span><span class="tag">${m.action || "\u2014"}</span></div>
      <p>${m.text}</p>
      <div class="powerRow__actions"><button class="iconBtn" data-action="remove-mutation" data-name="${escapeAttr(name)}" title="Forget">\u2715</button></div>
    </div>`;
  }).join("") : `<p class="muted">No mutations known yet \u2014 spend Mutation Points below.</p>`;
}

/* ---------------------------------- notes ---------------------------------- */
function renderNotes() { el("notesArea").value = state.notes; }

/* ============================== MODALS / PICKERS ============================ */
let pickerType = null;
let pickerFilter = { q: "", discipline: "All", level: "All", category: "All" };

function openPicker(type) {
  pickerType = type;
  pickerFilter = { q: "", discipline: "All", level: "All", category: "All", tier: "All" };
  el("pickerOverlay").style.display = "flex";
  el("pickerTitle").textContent = {
    weapon: "Add a weapon", armor: "Choose armor", item: "Add an item", modification: "Add a modification (reference only)",
    power: "Learn a power (spends PP)", mutation: "Learn a mutation (spends MP)", advancement: "Purchase an advancement (spends AP)",
  }[type];
  renderPickerFilters();
  renderPickerList();
}
function closePicker() { el("pickerOverlay").style.display = "none"; pickerType = null; }

function renderPickerFilters() {
  const bar = el("pickerFilters");
  let html = `<input type="text" placeholder="Search\u2026" value="${escapeAttr(pickerFilter.q)}" data-action="picker-search">`;
  if (pickerType === "power") {
    html += `<select data-action="picker-discipline">${["All", "Clairvoyance", "Ordination", "Sorcery", "Technomancy"].map((d) => opt(d, d, pickerFilter.discipline)).join("")}</select>`;
    html += `<select data-action="picker-level">${["All", 1, 2, 3].map((l) => opt(l, l === "All" ? "All levels" : "Level " + l, pickerFilter.level)).join("")}</select>`;
  }
  if (pickerType === "weapon") {
    html += `<select data-action="picker-category">${["All", "Blades", "Blasters", "Bows", "Polearms", "Unarmed"].map((c) => opt(c, c, pickerFilter.category)).join("")}</select>`;
    html += `<select data-action="picker-tier">${["All", "standard", "superior"].map((t) => opt(t, t === "All" ? "All tiers" : t === "standard" ? "Standard" : "Superior (II)", pickerFilter.tier)).join("")}</select>`;
  }
  if (pickerType === "item") {
    html += `<select data-action="picker-category">${["All", "Healing", "Protective", "Enhancing", "Explosives"].map((c) => opt(c, c, pickerFilter.category)).join("")}</select>`;
    html += `<select data-action="picker-tier">${["All", "standard", "superior"].map((t) => opt(t, t === "All" ? "All tiers" : t === "standard" ? "Standard" : "Superior (II)", pickerFilter.tier)).join("")}</select>`;
  }
  if (pickerType === "modification") {
    html += `<select data-action="picker-category">${["All", "Weapon", "Armor"].map((c) => opt(c, c, pickerFilter.category)).join("")}</select>`;
  }
  bar.innerHTML = html;
}

function pickerRows() {
  const q = pickerFilter.q.toLowerCase();
  if (pickerType === "weapon") {
    return D.WEAPONS.filter((w) => (pickerFilter.category === "All" || w.category === pickerFilter.category) && (pickerFilter.tier === "All" || w.tier === pickerFilter.tier) && w.name.toLowerCase().includes(q))
      .map((w) => ({
        title: w.name, meta: `${w.tier === "superior" ? "Superior \u00b7 " : ""}${w.category} \u00b7 ${w.cost}gc \u00b7 bulk ${w.bulk}${w.est ? "\u2020" : ""}`,
        body: `Atk +${w.atkAttr} \u00b7 ${w.range} \u00b7 ${w.dice}${w.dmgMod ? " +" + w.dmgMod : ""} ${w.dmgType} \u00b7 ${w.action}${w.special ? " \u2014 " + w.special : ""}`,
        onAdd: () => { state.attacks.push({ name: w.name }); },
      }));
  }
  if (pickerType === "armor") {
    return D.ARMOR.filter((a) => a.name.toLowerCase().includes(q)).map((a) => ({
      title: a.name, meta: `+${a.bonus} AR \u00b7 needs ${a.bodyReq} Body \u00b7 bulk ${a.bulk}`, body: "",
      onAdd: () => { state.armorEquipped = a.name; },
    }));
  }
  if (pickerType === "item") {
    return D.ITEMS.filter((it) => (pickerFilter.category === "All" || it.category === pickerFilter.category) && (pickerFilter.tier === "All" || it.tier === pickerFilter.tier) && it.name.toLowerCase().includes(q))
      .map((it) => ({
        title: it.name, meta: `${it.tier === "superior" ? "Superior \u00b7 " : ""}${it.category} \u00b7 ${it.cost}gc \u00b7 bulk ${it.bulk}`, body: it.text,
        onAdd: () => { state.inventory.push({ name: it.name, bulk: it.bulk, qty: 1, equipped: false, note: it.category }); },
      }));
  }
  if (pickerType === "modification") {
    return D.MODIFICATIONS.filter((m) => (pickerFilter.category === "All" || m.category === pickerFilter.category) && m.name.toLowerCase().includes(q))
      .map((m) => ({
        title: m.name, meta: `${m.category} mod \u00b7 ${m.cost}gc \u00b7 fits: ${m.fitsText}`, body: m.text,
        onAdd: () => { state.inventory.push({ name: m.name, bulk: 0, qty: 1, equipped: false, note: `${m.category} mod` }); },
      }));
  }
  if (pickerType === "power") {
    return D.POWERS.filter((p) =>
      (pickerFilter.discipline === "All" || p.discipline === pickerFilter.discipline) &&
      (pickerFilter.level === "All" || p.level === Number(pickerFilter.level)) &&
      p.name.toLowerCase().includes(q) && !state.powersKnown.includes(p.name)
    ).map((p) => ({
      title: p.name, meta: `${p.discipline} \u00b7 Lv${p.level} \u00b7 ${p.pp} PP \u00b7 ${p.action || "\u2014"} \u00b7 ${p.range}`, body: p.text,
      onAdd: () => { state.powersKnown.push(p.name); },
    }));
  }
  if (pickerType === "mutation") {
    return D.MUTATIONS.filter((m) => m.name.toLowerCase().includes(q) && !state.mutations.includes(m.name)).map((m) => ({
      title: m.name, meta: `${m.cost} MP \u00b7 ${m.action || "\u2014"}`, body: m.text,
      onAdd: () => { state.mutations.push(m.name); },
    }));
  }
  if (pickerType === "advancement") {
    return D.ADVANCEMENTS.filter((a) => a.name.toLowerCase().includes(q)).map((a) => ({
      title: a.name + (a.repeatable ? " (repeatable)" : ""), meta: `1 AP`, body: a.text,
      disabled: !a.repeatable && state.advancements[a.name],
      onAdd: () => { state.advancements[a.name] = (state.advancements[a.name] || 0) + 1; },
    }));
  }
  return [];
}

function renderPickerList() {
  const rows = pickerRows();
  el("pickerList").innerHTML = rows.length ? rows.map((r, i) => `
    <div class="pickerRow">
      <div class="pickerRow__text">
        <div class="pickerRow__title">${escapeHtml(r.title)} <span class="pickerRow__meta">${escapeHtml(r.meta)}</span></div>
        ${r.body ? `<p>${escapeHtml(r.body)}</p>` : ""}
      </div>
      <button class="btn btn--small" data-action="picker-add" data-index="${i}" ${r.disabled ? "disabled" : ""}>${r.disabled ? "Owned" : "Add"}</button>
    </div>`).join("") : `<p class="muted">Nothing matches.</p>`;
}

/* ============================== EVENT WIRING ============================ */
document.addEventListener("click", (e) => {
  const t = e.target.closest("[data-action]");
  if (!t) return;
  const action = t.dataset.action;

  if (action === "open-picker") return openPicker(t.dataset.type);
  if (action === "close-picker") return closePicker();
  if (action === "close-intro") { el("introOverlay").style.display = "none"; return; }
  if (action === "picker-add") {
    const rows = pickerRows();
    const row = rows[Number(t.dataset.index)];
    if (row && !row.disabled) { row.onAdd(); render(); renderPickerList(); }
    return;
  }
  if (action === "remove-attack") { state.attacks.splice(Number(t.dataset.index), 1); return render(); }
  if (action === "remove-inventory") { state.inventory.splice(Number(t.dataset.index), 1); return render(); }
  if (action === "remove-power") { state.powersKnown = state.powersKnown.filter((n) => n !== t.dataset.name); state.powersReadied = state.powersReadied.filter((n) => n !== t.dataset.name); return render(); }
  if (action === "remove-mutation") { state.mutations = state.mutations.filter((n) => n !== t.dataset.name); return render(); }
  if (action === "remove-advancement") {
    const name = t.dataset.name;
    if (state.advancements[name] > 1) state.advancements[name] -= 1;
    else {
      delete state.advancements[name];
      if (name === "Additional Path") { state.additionalPath = null; state.additionalPathPathway = null; }
    }
    return render();
  }
  if (action === "toggle-slot") {
    const tier = t.dataset.tier, idx = Number(t.dataset.idx);
    const max = slotTableRow()[tier - 1] || 0;
    const used = Math.min(state.powerSlotsUsed[tier] || 0, max);
    state.powerSlotsUsed[tier] = idx < used ? idx : idx + 1;
    return render();
  }
  if (action === "reset-slots") { state.powerSlotsUsed = { 1: 0, 2: 0, 3: 0 }; return render(); }
  if (action === "toggle-savebound") { state.saveBound = state.saveBound ? null : "Physical"; return render(); }
  if (action === "hp-delta") {
    const d = Number(t.dataset.delta);
    state.hp.current = Math.max(0, Math.min(state.hp.max, state.hp.current + d));
    return render();
  }
  if (action === "exhaustion-delta") {
    state.exhaustion = Math.max(0, Math.min(12, state.exhaustion + Number(t.dataset.delta)));
    return render();
  }
  if (action === "exhaustion-rest-short") { state.exhaustion = Math.max(0, state.exhaustion - 1); return render(); }
  if (action === "exhaustion-rest-long") { state.exhaustion = Math.max(0, state.exhaustion - 2); return render(); }
});

function applyFieldAction(t) {
  const action = t.dataset.action;

  if (action === "set-name") { state.name = t.value; return render(); }
  if (action === "set-species") { state.build.species = t.value; return render(); }
  if (action === "set-origin") { state.build.origin = t.value; return render(); }
  if (action === "set-role") { state.build.role = t.value; return render(); }
  if (action === "set-path") {
    state.build.path = t.value;
    state.build.pathway = "";
    return render();
  }
  if (action === "set-pathway") { state.build.pathway = t.value; return render(); }
  if (action === "set-level") { state.build.level = Math.max(1, Math.min(12, Number(t.value) || 1)); return render(); }
  if (action === "set-xp") {
    state.build.xp = Math.max(0, Number(t.value) || 0);
    state.build.level = levelForXp(state.build.xp);
    return render();
  }
  if (action === "set-attr") { state.attrs[t.dataset.attr] = Math.max(0, Math.min(12, Number(t.value) || 0)); return render(); }
  if (action === "set-hp-max") { state.hp.max = Math.max(0, Number(t.value) || 0); state.hp.current = Math.min(state.hp.current, state.hp.max); return render(); }
  if (action === "set-hp-current") { state.hp.current = Math.max(0, Math.min(state.hp.max, Number(t.value) || 0)); return render(); }
  if (action === "set-armor") { state.armorEquipped = t.value || null; return render(); }
  if (action === "set-savebound") { state.saveBound = t.value; return render(); }
  if (action === "toggle-equipped") { state.inventory[Number(t.dataset.index)].equipped = t.checked; return render(); }
  if (action === "toggle-readied") {
    const name = t.dataset.name;
    if (t.checked) {
      if (state.powersReadied.length < totalScore("Mind")) state.powersReadied.push(name); else { t.checked = false; alert("Readied powers can't exceed your Mind score."); }
    } else state.powersReadied = state.powersReadied.filter((n) => n !== name);
    return render();
  }
  if (action === "toggle-enraged") { state.enraged = t.checked; return render(); }
  if (action === "set-notes") { state.notes = t.value; return saveState(); }
  if (action === "set-ap-adj") { state.resourceAdj.ap = Number(t.value) || 0; return render(); }
  if (action === "set-mp-adj") { state.resourceAdj.mp = Number(t.value) || 0; return render(); }
  if (action === "set-pp-adj") { state.resourceAdj.pp = Number(t.value) || 0; return render(); }

  if (action === "choose-attrraise") {
    const i = Number(t.dataset.index);
    if (!t.value) { state.choices.attrRaise[i] = undefined; }
    else state.choices.attrRaise[i] = { attr: t.value };
    state.choices.attrRaise = state.choices.attrRaise.filter(Boolean);
    return render();
  }
  if (action === "choose-adeptskill") {
    const i = Number(t.dataset.index);
    if (!t.value) state.choices.adeptSkill[i] = undefined; else state.choices.adeptSkill[i] = { skill: t.value };
    state.choices.adeptSkill = state.choices.adeptSkill.filter(Boolean);
    return render();
  }
  if (action === "choose-adeptsave") {
    const i = Number(t.dataset.index);
    if (!t.value) state.choices.adeptSave[i] = undefined; else state.choices.adeptSave[i] = { save: t.value };
    state.choices.adeptSave = state.choices.adeptSave.filter(Boolean);
    return render();
  }
  if (action === "choose-additionalpath") { state.additionalPath = t.value || null; state.additionalPathPathway = null; return render(); }
  if (action === "choose-additionalpathpathway") { state.additionalPathPathway = t.value || null; return render(); }
  if (action === "picker-search") { pickerFilter.q = t.value; return renderPickerList(); }
  if (action === "picker-discipline") { pickerFilter.discipline = t.value; return renderPickerList(); }
  if (action === "picker-level") { pickerFilter.level = t.value; return renderPickerList(); }
  if (action === "picker-category") { pickerFilter.category = t.value; return renderPickerList(); }
  if (action === "picker-tier") { pickerFilter.tier = t.value; return renderPickerList(); }
}

// Selects and checkboxes fire a single, reliable "change" event. Text/number
// inputs are handled exclusively via "input" below — wiring them to both
// events risks a blur-triggered "change" re-rendering a list out from under
// a click that's already landing on it (e.g. typing a search term, then
// immediately clicking "Add").
document.addEventListener("change", (e) => {
  const t = e.target.closest("[data-action]");
  if (!t) return;
  const tag = t.tagName;
  const type = (t.type || "").toLowerCase();
  if (tag === "INPUT" && type !== "checkbox") return; // handled by "input"
  applyFieldAction(t);
});

// Text/number fields and the notes textarea should update live as you type,
// rather than waiting for the field to lose focus.
document.addEventListener("input", (e) => {
  const t = e.target.closest("[data-action]");
  if (!t) return;
  const tag = t.tagName;
  const type = (t.type || "").toLowerCase();
  if (tag === "SELECT" || type === "checkbox") return; // these are handled by "change" only
  applyFieldAction(t);
});

el("resetBtn").addEventListener("click", () => {
  if (confirm("Clear this character and start over? This can't be undone.")) { state = freshState(); saveState(); render(); }
});

/* ------------------------------- backup / load ------------------------------- */
el("backupBtn").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const safeName = (state.name || "trailblazer").trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-+|-+$)/g, "") || "trailblazer";
  const a = document.createElement("a");
  a.href = url;
  a.download = `${safeName}-backup.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
});

el("loadBackupInput").addEventListener("change", (e) => {
  const file = e.target.files && e.target.files[0];
  e.target.value = ""; // allow re-selecting the same filename later
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    let parsed;
    try {
      parsed = JSON.parse(reader.result);
    } catch (err) {
      alert("Couldn't read that file \u2014 make sure it's a backup exported from this sheet.");
      return;
    }
    if (!parsed || typeof parsed !== "object" || !parsed.build || !parsed.attrs) {
      alert("That doesn't look like a Trailblazer character backup.");
      return;
    }
    if (!confirm("Load this backup? It will replace your current character.")) return;
    state = Object.assign(freshState(), parsed);
    saveState();
    render();
  };
  reader.readAsText(file);
});

/* --------------------------------- intro modal -------------------------------- */
const INTRO_SEEN_KEY = "trailblazer-sheet-intro-seen-v1";
function maybeShowIntro() {
  try {
    if (localStorage.getItem(INTRO_SEEN_KEY)) return;
    localStorage.setItem(INTRO_SEEN_KEY, "1");
  } catch (e) {
    /* storage unavailable — show it this session and move on */
  }
  el("introOverlay").style.display = "flex";
}

/* -------------------------------- boot -------------------------------- */
render();
maybeShowIntro();
